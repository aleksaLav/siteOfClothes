<?php 
ob_start();
session_start();
include "config/connection.php";

if(isset($_SESSION['korisnik']) && $_SESSION['korisnik']->naziv=="admin"){
 header("Location: views/admin/admin.php");
}

include "views/fixed/head.php";
include "views/fixed/nav.php";


if(!isset($_GET['page'])){
    include "views/home.php";
}
else{
    switch($_GET['page']){
        case 'home':
        include "views/home.php";
        break;
        case 'blog':    
        include "views/blog.php";
        break;
        case 'faq':
        include "views/faq.php";
        break;
        case 'registr':
        include "views/registr.php";
        break;
        case 'contact':
        include "views/contact.php";
        break;
        case 'profil':
        include "views/profil.php";
        break;
        case 'author':
        include "views/autor.php";
        break;
    }

}


include "views/fixed/footer.php";
