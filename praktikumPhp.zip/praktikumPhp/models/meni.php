<?php

    $upit = "SELECT * FROM meni where user_admin=1";

    $izvrsi = $conn->query($upit)->fetchAll();
    
?>