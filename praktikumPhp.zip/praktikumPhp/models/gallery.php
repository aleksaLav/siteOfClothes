<?php 
  $upit = "SELECT * FROM galerija";

  $slike = $conn->query($upit)->fetchAll();
