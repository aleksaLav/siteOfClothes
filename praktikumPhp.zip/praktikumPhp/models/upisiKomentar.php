<?php

ob_start();
session_start();
if(isset($_POST['sendComment'])){
    $textComment=$_POST['textComment'];
    $korisnikId=$_SESSION['korisnik']->idKorisnik;
    $idPost=$_POST['idPost'];
    $stranica=$_POST['stranica'];
    
    include "../config/connection.php";

    $pripremaZaUpisKomentara= $conn-> prepare("INSERT into komentari values(null, :komentar)");
    $pripremaZaUpisKomentara->bindParam(':komentar',$textComment);
    
    $pripremaZaUpisPost_Komentar= $conn-> prepare("INSERT into post_komentar values(null, :idPost,:idKomentar)");
    $pripremaZaUpisPost_Komentar->bindParam(':idPost',$idPost);
    $pripremaZaUpisPost_Komentar->bindParam(':idKomentar',$poslednjiKomentar); 

    $pripremaZaUpisPostKomentar_korisnik = $conn-> prepare("INSERT into postkomentar_korisnik values(null, :idKorisnik, :idPostKomentar)");
    $pripremaZaUpisPostKomentar_korisnik->bindParam(':idKorisnik',$korisnikId);
    $pripremaZaUpisPostKomentar_korisnik->bindParam(':idPostKomentar',$poslednjiPostKomentar); 

    try {
        $conn->beginTransaction();
        $pripremaZaUpisKomentara->execute();
        $poslednjiKomentar = $conn->lastInsertId();
        $pripremaZaUpisPost_Komentar->execute();
        $poslednjiPostKomentar = $conn->lastInsertId();
        $pripremaZaUpisPostKomentar_korisnik->execute();
        $conn->commit();
       header("Location: ../index.php?page=blog&stranica=$stranica&postId=$idPost");
    } catch(PDOException $ex) {
     
        echo $ex->getMessage();
    }

    header("Location: ../index.php?page=blog&stranica=$stranica&postId=$idPost");
    
}
