<?php
include "../config/connection.php";
ob_start();
session_start();
if(isset($_SESSION['korisnik'])){
    require_once "../views/admin/models/statistika/functions.php";
    obrisiIzFajlaLogovanje($_SESSION['korisnik']->idKorisnik);
    unset($_SESSION['korisnik']);
    session_destroy();
    header("Location: ../index.php");
}
else{
    header("Location: ../index.php");
}