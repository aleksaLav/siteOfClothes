<?php
session_start();
ob_start();

$trenutnaStranica=isset($_GET['stranica'])?$_GET['stranica']:1;
$limit=2;
$kreni=($trenutnaStranica-1)*$limit;
include "../config/connection.php";
if(isset($_POST['newer'])){
    $_SESSION['pretraga']=true;
$sortiranjePoDatumuNovije=$conn->query("SELECT p.idPost,p.naslov,p.text,p.datum,p.podnaslov,p.text_podnaslov,(SELECT GROUP_CONCAT(s.naziv SEPARATOR '////') FROM slika_post s where p.idPost=s.idPost) as 'slike' FROM post p order BY p.datum desc ")->fetchAll();
$_SESSION['newerOlder']=$sortiranjePoDatumuNovije;
echo "new";
header("Location: ../index.php?page=blog");
}
elseif(isset($_POST['older'])){
    $_SESSION['pretraga']=true;
    $sortiranjePoDatumuNovije=$conn->query("SELECT p.idPost,p.naslov,p.text,p.datum,p.podnaslov,p.text_podnaslov,(SELECT GROUP_CONCAT(s.naziv SEPARATOR '////') FROM slika_post s where p.idPost=s.idPost) as 'slike' FROM post p order BY p.datum asc ")->fetchAll();
$_SESSION['newerOlder']=$sortiranjePoDatumuNovije;
echo "old";
header("Location: ../index.php?page=blog");
}

?>

