<?php
session_start();
ob_start();
$korisnikId=$_SESSION['korisnik']->idKorisnik;
if(isset($_POST["dugme"])) {
    $slika = $_FILES["slika"];
    $naziv = $slika["name"];

    $tmpPutanja = $slika["tmp_name"];
    $novaPutanja = "../assets/profilImage/$naziv";

    $uploaded = move_uploaded_file($tmpPutanja, $novaPutanja);

    $dimenzije = getimagesize($novaPutanja);
    $sirina = $dimenzije[0];
    $visina = $dimenzije[1];

    $novaSirina = 50;
    

    $novaVisina = $visina / ($sirina / $novaSirina);

    
    $ekstenzija = pathinfo($novaPutanja, PATHINFO_EXTENSION);
    $naziv = time()."_".$slika["name"];
    if($ekstenzija == "jpg") {
        $uploadedSlika = imagecreatefromjpeg($novaPutanja); 
        $platno = imagecreatetruecolor($novaSirina, $novaVisina);
        imagecopyresampled($platno, $uploadedSlika, 0, 0, 0, 0, $novaSirina, $novaVisina, $sirina, $visina);

        imagejpeg($platno, "../assets/litleProfilImage/$naziv", 100);
    }
    else { 
        $uploadedSlika = imagecreatefrompng($novaPutanja); 
        $platno = imagecreatetruecolor($novaSirina, $novaVisina);
        imagecopyresampled($platno, $uploadedSlika, 0, 0, 0, 0, $novaSirina, $novaVisina, $sirina, $visina);

        imagepng($platno, "../assets/litleProfilImage/$naziv.$ekstenzija", 100);
    }

    include "../config/connection.php";
    $_SESSION['korisnik']->slikaNaziv="$naziv.";
        $priprema = $conn->prepare("UPDATE korisnik SET slikaNaziv= :slika where idKorisnik = :id");
        $priprema->bindParam(":slika", $naziv);
        $priprema->bindParam(":id", $korisnikId);
        try {
            $uspelo = $priprema->execute();
            if($uspelo){
               header("Location: ../index.php?page=profil");
                $code = 202;
            }
            else{
                 $code = 422;
            }
        } catch (PDOException $e) {
                $code =409;
                echo $e->getMessage();
        }
       
}
