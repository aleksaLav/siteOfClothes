<?php
    function dohvatiPostove(){
        global $conn;

        $trenutnaStranica=isset($_GET['stranica'])?$_GET['stranica']:1;
        $limit=2;
        $kreni=($trenutnaStranica-1)*$limit;
        $brojPostova= $conn->query("SELECT count(*) as broj from post")->fetch()->broj;
        $broj = ceil($brojPostova/$limit);
    
        $upit = "SELECT p.idPost,p.naslov,p.text,p.datum,p.podnaslov,p.text_podnaslov,(SELECT GROUP_CONCAT(s.naziv SEPARATOR '////') FROM slika_post s where p.idPost=s.idPost) as 'slike' FROM post p order BY p.datum desc limit $kreni,$limit";
    
        $posts = $conn->query($upit)->fetchAll();
        $SviPostovi=$conn->query("SELECT * from post order BY datum desc")->fetchAll();
         $komentarIspis= $conn->query("SELECT * from korisnik k inner join postkomentar_korisnik pkk on k.idKorisnik=pkk.idKorisnik inner join post_komentar pk on pkk.idPostKomentar=pk.idPostKomentar inner join komentari kom on pk.idKomentar=kom.idKomentar");

         return ["posts"=>$posts,"brojPostova"=>$broj,"komentarIspis"=>$komentarIspis,"SviPostovi"=>$SviPostovi];
    }
    function parsiranjeSlika($element){
        $result= explode("////",$element);
           return $result[0];
   }
    function parsiranjeSlikaPodnaslov($element){
        $result= explode("////",$element);
        return $result[1];
    }
?>