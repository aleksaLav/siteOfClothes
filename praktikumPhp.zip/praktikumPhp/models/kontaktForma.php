<?php

ob_start();
header("Content-type:application/json");
session_start();
$code = 404;
$data = null;

if(isset($_POST['sendMessageButton'])){
    $name=$_POST['name'];
    $phone=$_POST['phone'];
    $email=$_POST['email'];
    $message=$_POST['message'];

    $regName = "/^[A-ZŽĐŠČĆ][a-zžđščć]{2,20}(\s[A-ZŽĐŠČĆ][a-zžđščć]{2,20})+$/";
    $regPhone="/^(06[0-9]|\+3816[0-9])[\d]{3}[\d]{3,4}$/";
    $regEmail="/^[A-zžđščć][A-zžđščć\d\_\.\-]+\@[a-z]{3,10}(\.[a-z]{2,4})+$/";
    $regMessage= "/^.{15,99}$/";
    
    $greske = [];
    
    if(!preg_match($regName, $name)){
        $greske[] = "name nije ok !";
    }

    if(!preg_match($regPhone, $phone)){
        $greske[] = "phone nije ok !";
    }

    if(!preg_match($regEmail, $email)){
        $greske[] = "email nije 0ok!";
    }

    if(!preg_match($regMessage, $message)){
        $greske[] = "Poruka je prekratka ili predugacka!";
    }

    if(count($greske) == 0) {
        include "../config/connection.php";

        $pripremaZaUpis= $conn-> prepare("INSERT into kontakt_forma values(null, :name, :phone, :email, :message)");
    
        $pripremaZaUpis->bindParam(':name',$name);
        $pripremaZaUpis->bindParam(':phone',$phone);
        $pripremaZaUpis->bindParam(':email',$email);
        $pripremaZaUpis->bindParam(':message',$message);
    
        
        try {
            $uspelo = $pripremaZaUpis->execute();

            if($uspelo){
                $code = 202;
                header("Location: ../index.php?page=contact");
            }
            else{
                $code = 500;
            }
        } catch(PDOException $ex) {
            $code=409;
            echo $ex->getMessage();
        }
    }
    else{
        $data = $greske;
        $code = 422;
        header("Location: ../index.php?page=contact");
    }
    http_response_code($code);
    echo json_encode($data);
}
