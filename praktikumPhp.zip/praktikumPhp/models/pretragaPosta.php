<?php

ob_start();
session_start();
header("Content-type: application/json");
 $code=404;
if(isset($_POST['pretraga'])){
    $_SESSION['pretraga']=$_POST['pretraga'];
    $naslovIzPretrage="%".$_POST['naslovIzPretrage']."%";
    
    include "../config/connection.php";
    $postovi=$conn->query("SELECT * from post")->fetchAll();
    $postFilter= $conn->prepare( "SELECT p.idPost,p.naslov,p.text,p.datum,p.podnaslov,p.text_podnaslov,(SELECT GROUP_CONCAT(s.naziv SEPARATOR '////') FROM slika_post s where p.idPost=s.idPost) as 'slike' FROM post p  WHERE p.naslov like :naslovIzPretrage order BY p.datum desc");
    
    try {
        $conn->beginTransaction();
        $postFilter->bindParam(':naslovIzPretrage',$naslovIzPretrage);
        $postFilter->execute();
        $code=$postFilter->execute()?201:500;
        $data = $postFilter->fetchAll();
        $conn->commit();
        if(count($data)==0){
          $code=422;
        }

        $_SESSION["postFilter"]=$data;
    } catch(PDOException $ex) {
         $code=409;
        echo $ex->getMessage();
    }
   echo http_response_code($code);
    
}




