<?php

ob_start();
header("Content-type:application/json");
session_start();
$code = 404;
$data = null;

if(isset($_POST['sendMessageButton'])){
   
    $name=$_POST['name'];
    $surname=$_POST['surname'];
    $email=$_POST['email'];
    $userName=$_POST['userName'];
    $password=$_POST['password'];
    $passwordAgain = $_POST['againPass'];

    $regName = "/^[A-ZŽĐŠČĆ][a-zžđščć]{2,20}(\s[A-ZŽĐŠČĆ][a-zžđščć]{2,20})?$/";
    $regPhone="/^(06[0-9]|\+3816[0-9])[\d]{3}[\d]{3,4}$/";
    $regEmail="/^[A-zžđščć][A-zžđščć\d\_\.\-]+\@[a-z]{3,10}(\.[a-z]{2,4})+$/";
    $regUserName="/^[A-zžđščć\s\/\-\_\+\@\,\.\'\"\%\d]{3,15}$/";
    $regPass="/^.{4,15}$/";
   
    $greske = [];

    if(!preg_match($regName, $name)){
        $greske[] = "Read the instructions below the name field!";
    }
    if(!preg_match($regName, $surname)){
        $greske[] = "Read the instructions below the surname field!";
    }
    if(!preg_match($regEmail, $email)){
        $greske[] = "Read the instructions below the email field!";
    }
    if(!preg_match($regUserName, $userName)){
        $greske[] = "Read the instructions below the userName field!";
    }
    if(!preg_match($regPass, $password)){
        $greske[] = "Read the instructions below the password field!";
    }
    if($password!=$passwordAgain){
        $greske[] = "Passwords do not match!";
    }

    if(count($greske) == 0) {
        include "../config/connection.php";

        $pripremaZaUpis= $conn-> prepare("INSERT into korisnik (idKorisnik,ime,prezime, email,lozinka, korisnickoIme,idUloga) values(null, :name, :surname, :email, :password, :userName,2)");
    
        $pripremaZaUpis->bindParam(':name',$name);
        $pripremaZaUpis->bindParam(':surname',$surname);
        $pripremaZaUpis->bindParam(':email',$email);
        $password = md5($password);
        $pripremaZaUpis->bindParam(':password',$password);
        $pripremaZaUpis->bindParam(':userName',$userName);
        
    
        
        try {
            $uspelo = $pripremaZaUpis->execute();
            
            if($uspelo){
                $code = 202;
                header("Location: ../index.php?page=registr");
            }
            else{
                $code = 500;
            }
        } catch(PDOException $ex) {
            
            $code =409;
            echo $ex->getMessage();
            
            header("Location: ../index.php?page=registr");
            
        }
    }
    else{
        $data = $greske;
        $code = 422;
       
        header("Location: ../index.php?page=registr");
    }
    http_response_code($code);
    echo json_encode($data);
}

