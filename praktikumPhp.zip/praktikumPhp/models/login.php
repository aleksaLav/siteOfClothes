<?php

ob_start();
header("Content-type: application/json");
 session_start();
$code = 404;
$data = null;

if(isset($_POST['send'])){

    $userName=$_POST['userName'];
    $password=$_POST['password'];

    $regUserName="/^[A-zžđščć\s\/\-\_\+\@\,\.\'\"\%\d]{3,15}$/";
    $regPass="/^.{4,15}$/";

    $greske = [];
    
    if(!preg_match($regUserName, $userName)){
        $greske[] = "Username must contain a min of 3 and a max of 15 characters!";
    }

    if(!preg_match($regPass, $password)){
        $greske[] = "Password must contain a min of 4 and a max of 15 characters";
    }

    if(count($greske) == 0) {
        include "../config/connection.php";

        $priprema = $conn->prepare("SELECT k.*,u.nazivUloga AS naziv FROM korisnik k INNER JOIN uloga u ON k.idUloga = u.id WHERE korisnickoIme = :korisnickoIme AND lozinka = :lozinka");
        
      
        $priprema->bindParam(":korisnickoIme", $userName);

        $password = md5($password);
        
        $priprema->bindParam(":lozinka", $password);

        try {
            $uspelo = $priprema->execute();
            if($uspelo && $priprema->rowCount() == 1){
                $korisnik = $priprema->fetch();
                $_SESSION['korisnik'] = $korisnik;
                require_once "../views/admin/models/statistika/functions.php";
                zabeleziLogovanjeUfajlLogovanje($_SESSION['korisnik']->idKorisnik);
                if($korisnik->naziv == "user"){
                    header("Location: ../index.php");
                   
                } else if($korisnik->naziv == "admin"){
                    header("Location: ../admin.php");
                }
                
                $code = 202;
            }
            else{

                $upitZaUsername = "SELECT k.*,u.nazivUloga  FROM korisnik k INNER JOIN uloga u ON k.idUloga = u.id WHERE k.korisnickoIme = ?";

            try {
                $result = $conn->prepare($upitZaUsername);

                $result->execute([$userName]);
                $korisnik2 = $result->fetch();

                if($result->rowCount() == 1){
                    $to  = $korisnik2->email;
                    $subject = 'Login failed';
                    $message = 'Someone tried to log in to your account and made a mistake. Was that you?';
                    $headers = 'From: admin@gmail.com' . "\r\n" .
                        'Reply-To:'.$korisnik2->email . "\r\n" .
                        'X-Mailer: PHP/' . phpversion();
                    
                    mail($to, $subject, $message, $headers);
                }

                } catch (PDOException $e) {
                    echo $e->getMessage();
                    noteErrorInFile($e->getMessage());
                }
                
                header("Location: ../index.php");
                 $code = 422;
            }
        } catch (PDOException $e) {
                $code =409;
                echo $e->getMessage();
        }   

    }else {
        $data = $greske;
        $code = 422;
    }
    http_response_code($code);
    echo json_encode($data);
}
else{
        $code = 500;
    }
    http_response_code($code);
