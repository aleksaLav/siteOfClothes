$(document).ready(function(){
    $("#ulogujSe").on("click", ulogujSe);
    $("#pretraga").on("click", pretrazi);
    $("#sendMessageButton").on("click",pozivanjeRegistracije);
     $("#sendMessage").on("click",pozivanjeKontakt);
})

function ulogujSe() {
    var korisnickoIme = $("#loginid").val().trim();
    var lozinka = $("#loginpsw").val().trim();

    $.ajax({
        url: "models/login.php",
        method: "POST",
        data: {
            userName: korisnickoIme,
            password: lozinka,
            send: true
        },
        dataType: "json",
        success: function (data) {
            alert("You have successfully logged in!");
             location.reload();
        },
        error: function (xhr, error, status) {
            console.log(xhr.responseText);
            console.log(xhr.responseJson);
            console.log(error);
            console.log(status);

            let code = xhr.status;
            let poruka = "An error has occurred !";
            switch (code) {
                case 404:
                    poruka = "Page not found!";  
                    break;
                case 409:
                    poruka = "The request was denied, please try again!";
                    break;
                case 422:
                    poruka = "Check your credentials!";
                    break;
                case 500:
                    poruka = "Server error, please try again!";
                    break;

            }
            alert(poruka);
            var jsonGreske = xhr.responseJSON;
            console.log(jsonGreske);
            let ispis = ``;
            for (let item of jsonGreske) {
                ispis += "<b class='text-danger'>"+item + "</b><br/>";
            }
             jsonGreske=[]
              $("#error-login").html(ispis);
        }
    })
}
function pretrazi(){
    let naslovIzPretrage = $("#naslovIzPretrage").val().trim();
    $.ajax({
        url: "models/pretragaPosta.php",
        method: "POST",
        data: {
            naslovIzPretrage:naslovIzPretrage,
            pretraga: true
        },
        dataType: "json",
        success: function (data) {
             location.reload();
        },
        error: function (xhr, error, status) {
            console.log(xhr.responseText);
            console.log(xhr.responseJson);
            console.log(error);
            console.log(status);

            let code = xhr.status;
            let poruka = "An error has occurred !";
            switch (code) {
                case 404:
                    poruka = "Page not found!";  
                    break;
                case 409:
                    poruka = "The request was denied, please try again!";
                    break;
                case 422:
                    poruka = "The requested post was not found!";
                    break;
                case 500:
                    poruka = "Server error, please try again!";
                    break;

            }
            alert(poruka);
            // var jsonGreske = xhr.responseJSON;
            // // console.log(jsonGreske);
            // let ispis = ``;
            // for (let item of jsonGreske) {
            //     ispis += "<b>"+item + "</b><br/>";
            // }
            //  jsonGreske=[]
            //   $("#error-login").html(ispis);
        }
    })
}
function proveraRegistracije(){
     var validno = true;
    var ime=$("#imeRegister").val().trim();
    var Prez=$("#PrezimeRegister").val().trim();
    var Email=$("#emailRegister").val().trim();
    var korisnickoIme=$("#korisnickoIme").val().trim();
    var lozinka=$("#lozinka").val().trim();
    var potvrdaLozinke=$("#lozinkaPotvrda").val().trim();

    var REGimePrezime=/^[A-ZŽĐŠČĆ][a-zžđščć]{2,14}(\s[A-ZŽĐŠČĆ][a-zžđščć]{2,14})?$/;
    var REGemail =/^[A-zžđščć][A-zžđščć\d\_\.\-]+\@[a-z]{3,10}(\.[a-z]{2,4})+$/;
     var REGkorisnickoIme=/^[A-zžđščć\s\/\-\_\+\@\,\.\'\"\%\d]{3,15}$/;
     var REGlozinka=/^.{4,15}$/;
    
     if(!REGimePrezime.test(ime)){
         
         $("#errorRegisterName").html("Read the instructions below the input field!");
         validno =false;
     }else{
        $("#errorRegisterName").html("");
    }
     if(!REGimePrezime.test(Prez)){
         
        $("#errorRegisterSurname").html("Read the instructions below the input field!");
        validno =false;
    }else{
        $("#errorRegisterSurname").html("");
    }
     if(!REGemail.test(Email)){
         $("#errorRegisterEmail").html("Read the instructions below the input field!");
         validno =false;
     }
     else{
        $("#errorRegisterEmail").html("");
    }
     if(!REGkorisnickoIme.test(korisnickoIme)){
         $("#errorRegisterUserName").html("Read the instructions below the input field!");
         validno =false;
     }
     else{
        $("#errorRegisterUserName").html("");
    }
     if(!REGlozinka.test(lozinka)){
         $(".errorRegisterPassword").html("The password is too short, it must contain min 4, max 15 characters!");
         validno =false;
     }
     else if(lozinka!=potvrdaLozinke){
         $(".errorRegisterPassword").html("Passwords do not match!");
         validno =false;
     }
     else{
        $(".errorRegisterPassword").html("");
    }
     return validno;
}
function registracijaObrada(){
        var ime = $("#imeRegister").val().trim();
        var prez = $("#PrezimeRegister").val().trim();
        var email = $("#emailRegister").val().trim();
        var korisnickoIme = $("#korisnickoIme").val().trim();
        var lozinka = $("#lozinka").val().trim();
        var againPass = $("#lozinkaPotvrda").val().trim();
        $.ajax({
            url: "models/registracija.php",
            method: "POST",
            data: {
                name: ime,
                surname: prez,
                email: email,
                userName: korisnickoIme,
                password: lozinka,
                againPass: againPass,
                sendMessageButton: true
            },
            dataType: "json",
            success: function (data) {
                alert("You have successfully registered!");
                location.reload();
            },
            error: function (xhr, error, status) {
                console.log(xhr.responseText);
                console.log(xhr.responseJson);
                console.log(error);
                console.log(status);

                let code = xhr.status;
                let poruka = "An error has occurred!";
                switch (code) {
                    case 404:
                        poruka = "Page not found!";  
                        break;
                    case 409:
                        poruka = "This email or username already exists!";
                        break;
                    case 422:
                        poruka = "There was an error registering! Check the data!";
                        break;
                    case 500:
                        poruka = "Server error, please try again!";
                        break;

                }
                alert(poruka);
                var jsonGreske = xhr.responseJSON;
                console.log(jsonGreske);
                let ispis = ``;
                for (let item of jsonGreske) {
                    ispis += "<b>"+item + "</b><br/>";
                }
                 jsonGreske=[]
                let pozicija= document.getElementById("greskeRegistracija").offsetTop;
                  document.body.scrollTop = pozicija/2;
                  document.documentElement.scrollTop = pozicija /2;
                  $("#greskeRegistracija").html(ispis);
            }
        })
}
function pozivanjeRegistracije(){
    if(proveraRegistracije()){registracijaObrada()}else{proveraRegistracije()}
}
function kontakObrada(){
    var ime = $("#name").val().trim();
    var phone = $("#phone").val().trim();
    var email = $("#email").val().trim();
    var message = $("#message").val().trim();
    $.ajax({
        url: "models/kontaktForma.php",
        method: "POST",
        data: {
            name: ime,
            phone: phone,
            email: email,
            message: message,
            sendMessageButton: true
        },
        dataType: "json",
        success: function (data) {
            alert("Message has been sent!");
            location.reload();
        },
        error: function (xhr, error, status) {
            console.log(xhr.responseText);
            console.log(xhr.responseJson);
            console.log(error);
            console.log(status);

            let code = xhr.status;
            let poruka = "An error has occurred!";
            switch (code) {
                case 404:
                    poruka = "Page not found!";  
                    break;
                case 409:
                    poruka = "The request was denied, please try again!";
                    break;
                case 422:
                    poruka = "An error occurred while sending the message ! Check the data!";
                    break;
                case 500:
                    poruka = "Server error, please try again!";
                    break;

            }
            alert(poruka);
            var jsonGreske = xhr.responseJSON;
            console.log(jsonGreske);
            let ispis = ``;
            for (let item of jsonGreske) {
                ispis += "<b>"+item + "</b><br/>";
            }
             jsonGreske=[]
            let pozicija= document.getElementById("error-contact").offsetTop;
              document.body.scrollTop = pozicija/2;
              document.documentElement.scrollTop = pozicija /2;
              $("#greskeRegistracija").html(ispis);
        }
    })
}
function proveraKontakt(){
    
    var validno = true;
    var ime = $("#name").val().trim();
    var phone = $("#phone").val().trim();
    var email = $("#email").val().trim();
    var message = $("#message").val().trim();

    var regName = /^[A-ZŽĐŠČĆ][a-zžđščć]{2,20}(\s[A-ZŽĐŠČĆ][a-zžđščć]{2,20})+$/;
    var regPhone=/^(06[0-9]|\+3816[0-9])[\d]{3}[\d]{3,4}$/;
    var regEmail=/^[A-zžđščć][A-zžđščć\d\_\.\-]+\@[a-z]{3,10}(\.[a-z]{2,4})+$/;
    var regMessage= /^.{15,99}$/;
   
    if(!regName.test(ime)){
        $("#error-name").html("Read the instructions below the input field!");
        validno =false;
    }else{
       $("#error-name").html("");
   }
    if(!regPhone.test(phone)){
        
       $("#error-phone").html("Read the instructions below the input field!");
       validno =false;
   }else{
       $("#error-phone").html("");
   }
    if(!regEmail.test(email)){
        $("#error-email").html("Read the instructions below the input field!");
        validno =false;
    }
    else{
       $("#error-email").html("");
   }
    if(!regMessage.test(message)){
        $("#error-message").html("Read the instructions below the input field!");
        validno =false;
    }
    else{
       $("#error-message").html("");
   }
    return validno;
}
function pozivanjeKontakt(){
    if(proveraKontakt()){kontakObrada()}else{proveraKontakt()}
}