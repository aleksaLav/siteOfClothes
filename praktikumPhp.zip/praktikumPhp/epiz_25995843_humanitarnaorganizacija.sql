-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql202.byetcluster.com
-- Generation Time: Jun 20, 2020 at 09:52 AM
-- Server version: 5.6.47-87.0
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `epiz_25995843_humanitarnaorganizacija`
--

-- --------------------------------------------------------

--
-- Table structure for table `galerija`
--

CREATE TABLE `galerija` (
  `id_gallery` int(3) NOT NULL,
  `alt` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `href` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `galerija`
--

INSERT INTO `galerija` (`id_gallery`, `alt`, `href`) VALUES
(1, 'help you too', 'images.jfif'),
(2, 'let everyone know', 'africa-education.jpg'),
(3, 'help educate others', 'old-books-436498_1280.jpg'),
(4, 'let everyone have a happy childhood', 'doll-87407_1280.jpg'),
(5, 'one meal much hope', 'hunger-682834_1280.jpg'),
(6, 'human rights in the first place', 'human-rights.jpg'),
(7, 'donate for happiness', 'girl-62328_1280.jpg'),
(8, 'for the equality of all', 'children-60654_1280.jpg'),
(9, 'help', 'child-207573_1280.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `komentari`
--

CREATE TABLE `komentari` (
  `idKomentar` int(12) NOT NULL,
  `komentar` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kontakt_forma`
--

CREATE TABLE `kontakt_forma` (
  `idKontakt` int(5) NOT NULL,
  `ime_prezime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `telefon` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `poruka` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `kontakt_forma`
--

INSERT INTO `kontakt_forma` (`idKontakt`, `ime_prezime`, `telefon`, `email`, `poruka`) VALUES
(1, 'Aleksa Stosic', '064-555-6666ff', 'aki.sto99@gmail.com', 'gdsfgdsgdsgfdsgfdsgfdsgds'),
(2, 'Aleksa Stosic', '0652261526', 'aki.sto99@gmail.com', 'dsflkfklds akfdsakl fdsaklf klklfdsa klklsdfakl ds'),
(3, 'Aleksa Stosic', '0652261526', 'aki.sto99@gmail.com', 'dsflkfklds akfdsakl fdsaklf klklfdsa klklsdfakl ds'),
(4, 'Aleksa Stosic', '0652261526', 'aki.sto99@gmail.com', 'dsflkfklds akfdsakl fdsaklf klklfdsa klklsdfakl ds'),
(5, 'Aleksa Stosic', '0642261526', 'aki.sto99@gmail.com', 'jiwetijotewij ijtewijewijewqij ewij ijewriji jerw'),
(6, 'Dva Fsdffdsfs', '0642224444', 'aki.sto99@gmail.com', 'gdsfgfdgfdgadgGSGSDA GSD DS GDSF GSDF');

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `idKorisnik` int(5) NOT NULL,
  `ime` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `prezime` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lozinka` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `idUloga` int(1) NOT NULL,
  `slikaNaziv` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `korisnickoIme` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`idKorisnik`, `ime`, `prezime`, `email`, `lozinka`, `idUloga`, `slikaNaziv`, `korisnickoIme`) VALUES
(14, 'Aleksa Stosic', 'Aleksa Stosic', 'aki.sto99@gmail.com', 'f3071ec919ba79ea9d6fbe49c2c53a3d', 2, '1592438972_deca-Unicef.jpg', 'aki123'),
(17, 'Neko', 'Bitan', 'niko.bitan@gmail.com', 'f3071ec919ba79ea9d6fbe49c2c53a3d', 1, '', 'neko123'),
(18, 'Dejan', 'Djekic', 'deki@gmail.com', 'f3071ec919ba79ea9d6fbe49c2c53a3d', 1, '', 'dekiki123'),
(20, 'Stefan Stefi', 'Vaskovic', 'vaskovic.stefan@gmail.com', 'f3071ec919ba79ea9d6fbe49c2c53a3d', 1, '', 'stefi123'),
(21, 'Milena', 'Vesec', 'milena.vesic@ict.edu.rs', '8c98108034aaeade5fec8d04dceb4bfb', 2, '', 'milena123'),
(24, 'Pera', 'Admin', 'admin@gamil.com', '6aabc339fbebd5269f202ceb7727fcd3', 1, '', 'pera123'),
(25, 'Dragan', 'Sestric', 'daki536@etf.edu.rs', 'f3071ec919ba79ea9d6fbe49c2c53a3d', 2, '', 'daki_14');

-- --------------------------------------------------------

--
-- Table structure for table `meni`
--

CREATE TABLE `meni` (
  `id` int(3) NOT NULL,
  `naziv` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `href` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dropdown` tinyint(1) NOT NULL,
  `user_admin` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `meni`
--

INSERT INTO `meni` (`id`, `naziv`, `href`, `dropdown`, `user_admin`) VALUES
(1, 'HOME', 'index.php', 0, 1),
(2, 'ABOUT US', 'index.php?page=faq', 0, 1),
(3, 'Blog', 'index.php?page=blog', 0, 1),
(4, 'Registration', 'index.php?page=registr', 0, 1),
(5, 'CONTACT', 'index.php?page=contact', 0, 1),
(6, 'Sign in', NULL, 0, 1),
(8, 'Documentation', 'Documentation.pdf', 1, 1),
(9, 'About Autor', 'index.php?page=author', 1, 1),
(11, 'Add post', 'admin.php?page=addPost', 0, 2),
(12, 'Users', 'admin.php?page=users', 0, 2),
(13, 'Posts', 'admin.php?page=posts', 0, 2),
(14, 'Contacts', 'admin.php?page=contact', 0, 2),
(15, 'Visits', 'admin.php?page=visits', 0, 2),
(16, 'Log out', '../../models/logout.php', 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `idPost` int(5) NOT NULL,
  `naslov` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `text` text COLLATE utf8_unicode_ci NOT NULL,
  `podnaslov` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `text_podnaslov` text COLLATE utf8_unicode_ci NOT NULL,
  `datum` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`idPost`, `naslov`, `text`, `podnaslov`, `text_podnaslov`, `datum`) VALUES
(12, 'Free “Ne damo Svetinje” for everyone in Montenegro', 'Our “Ne damo svetinje” initiative in support of free and democratic principles in Montenegro has been underway for several days now. The diaspora’s support has allowed the good people of Montenegro to stand up and voice their opinions and needs. We thank you all sincerely for this continued show of solidarity and unity.\r\n\r\nAs a token of our gratitude to all those who have supported this cause— and with it, the right of the people of Montenegro to democratically and peacefully choose their laws and elect their leadership—28. Jun will donate 100 “Ne damo svetinje” T-shirts directly to the people of Montenegro, free of charge.\r\n\r\nT-shirts will be distributed by Vladislav Dajkovic, who is currently leading efforts to support the protesters of Montenegro in their struggle for democracy. To get your free shirt, contact Vladislav via Facebook. The first 100 people to do so will get a shirt on a first-come, first-served basis.', 'They did not believe that a miracle was possible', 'We want to see you in our shirts! If you’ve purchased or won a “Ne damo svetinje” T-shirt, post a photo and tag #nedamosvetinje, @28jun and @vladislav_dajkovic. We’ll happily share your photos and messages of support for this great cause.\r\n\r\nAs a reminder, members of the diaspora who would like to continue supporting this cause can still purchase a shirt through our online shop: https://28jun.myshopify.com/\r\n\r\nProceeds from this initiative will directly support underprivileged families in Montenegro during this trying period.\r\n\r\nSupport Pravo Izbora!', '2020-06-16 12:09:12'),
(16, 'Medical aid donated during COVID-19 pandemic', '28. Jun is proud to inform you that a donation of medical aid sent to Serbia through our fundraising and volunteer efforts was used by the Serbian government during the crisis response to the COVID-19 pandemic.\r\n\r\nOur team is grateful for the cooperation of all agencies and personnel involved in this effort. We are incredibly happy to have had the opportunity to contribute to the greater response to this crisis and, in doing so, have had the chance to give back to the Serbian community in this time of need.\r\n\r\nWe would like to extend a special thank you to our American partner ‘Supplies Over Seas’, without whom this delivery would not have been possible. We hope that this cooperation will set a precedent for future collaboration.', '', '', '2020-06-17 04:10:48'),
(17, '“Dad, Dad, a lizard” – they lived in a house with 300 snakes', 'An incredible, bizarre story took place in the village of Drnovac, by Boljevac. One night, a few years ago, the Šimunović family discovered as many as 300 snakes in their home. The parents and their three children immediately evacuated the home, which was later discovered to have snakes in the walls, foundation and attic.\r\nToday they once again live in that house, which is a renovated barn. They continue to come across the occasional snake.', '', 'We are where we are, in two barely functional rooms. The ceiling is cracked, we don’t have a proper foundation. The only worthwhile thing is the view of the famous Rtanj mountain...Our daughters are in school, and Milan (18) helps collect herbs to make medicinal teas. We have a small orchard with plums, pears, apples...All that we earn goes toward food.\r\nThe Šimunović family was also visited by members of the Charity organization Serbs for Serbs.', '2020-06-17 04:42:23');

-- --------------------------------------------------------

--
-- Table structure for table `postkomentar_korisnik`
--

CREATE TABLE `postkomentar_korisnik` (
  `idpostKoment_Koris` int(255) NOT NULL,
  `idKorisnik` int(255) NOT NULL,
  `idPostKomentar` int(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `post_komentar`
--

CREATE TABLE `post_komentar` (
  `idPostKomentar` int(255) NOT NULL,
  `idPost` int(5) NOT NULL,
  `idKomentar` int(12) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `slika_post`
--

CREATE TABLE `slika_post` (
  `idSlika` int(10) NOT NULL,
  `naziv` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `idPost` int(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `slika_post`
--

INSERT INTO `slika_post` (`idSlika`, `naziv`, `idPost`) VALUES
(29, '1592334552_103943528_1473139802873832_2283273097564458437_o.jpg', 12),
(35, '1592392247_donacija.jfif', 16),
(36, '1592394143_simunovic-boljevac2_resize.jpg', 17),
(37, '1592394143_simunovic-boljevac10_resize.jpg', 17),
(38, '1592402999_donacija.jfif', 18);

-- --------------------------------------------------------

--
-- Table structure for table `uloga`
--

CREATE TABLE `uloga` (
  `id` int(5) NOT NULL,
  `nazivUloga` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `uloga`
--

INSERT INTO `uloga` (`id`, `nazivUloga`) VALUES
(1, 'admin'),
(2, 'user');

-- --------------------------------------------------------

--
-- Table structure for table `user_admin_nav`
--

CREATE TABLE `user_admin_nav` (
  `id_user_admin` int(1) NOT NULL,
  `user_admin` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_admin_nav`
--

INSERT INTO `user_admin_nav` (`id_user_admin`, `user_admin`) VALUES
(1, 'user'),
(2, 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `galerija`
--
ALTER TABLE `galerija`
  ADD PRIMARY KEY (`id_gallery`);

--
-- Indexes for table `komentari`
--
ALTER TABLE `komentari`
  ADD PRIMARY KEY (`idKomentar`);

--
-- Indexes for table `kontakt_forma`
--
ALTER TABLE `kontakt_forma`
  ADD PRIMARY KEY (`idKontakt`);

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`idKorisnik`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `korisnickoIme` (`korisnickoIme`),
  ADD KEY `idUloga` (`idUloga`);

--
-- Indexes for table `meni`
--
ALTER TABLE `meni`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_admin` (`user_admin`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`idPost`);

--
-- Indexes for table `postkomentar_korisnik`
--
ALTER TABLE `postkomentar_korisnik`
  ADD PRIMARY KEY (`idpostKoment_Koris`),
  ADD KEY `idKorisnik` (`idKorisnik`),
  ADD KEY `idPostKomentar` (`idPostKomentar`);

--
-- Indexes for table `post_komentar`
--
ALTER TABLE `post_komentar`
  ADD PRIMARY KEY (`idPostKomentar`),
  ADD KEY `idPost` (`idPost`),
  ADD KEY `idKomentar` (`idKomentar`);

--
-- Indexes for table `slika_post`
--
ALTER TABLE `slika_post`
  ADD PRIMARY KEY (`idSlika`),
  ADD KEY `idPost` (`idPost`),
  ADD KEY `idSlika_2` (`idSlika`),
  ADD KEY `idSlika_3` (`idSlika`);

--
-- Indexes for table `uloga`
--
ALTER TABLE `uloga`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_admin_nav`
--
ALTER TABLE `user_admin_nav`
  ADD PRIMARY KEY (`id_user_admin`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `galerija`
--
ALTER TABLE `galerija`
  MODIFY `id_gallery` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `komentari`
--
ALTER TABLE `komentari`
  MODIFY `idKomentar` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `kontakt_forma`
--
ALTER TABLE `kontakt_forma`
  MODIFY `idKontakt` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `idKorisnik` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `meni`
--
ALTER TABLE `meni`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `idPost` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `postkomentar_korisnik`
--
ALTER TABLE `postkomentar_korisnik`
  MODIFY `idpostKoment_Koris` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `post_komentar`
--
ALTER TABLE `post_komentar`
  MODIFY `idPostKomentar` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `slika_post`
--
ALTER TABLE `slika_post`
  MODIFY `idSlika` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `uloga`
--
ALTER TABLE `uloga`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_admin_nav`
--
ALTER TABLE `user_admin_nav`
  MODIFY `id_user_admin` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
