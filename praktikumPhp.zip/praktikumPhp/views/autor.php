<div class="container">
<div class="col-12 d-flex justify-content-around align-item-center flex-wrap">
<h2 class="pt-5 pb-5 w-100 d-flex justify-content-center">Author: Aleksa Stosic, 108/18</h2>
<div class="pt-5 pb-5">
<img src="assets/images/1592333185_IMG_20171121_171029_010.jpg" alt="author" />
</div>
<p class="mt-4 autorP">I have been studying at the ICT high school for two years, I have several projects behind me, I am constantly improving and getting acquainted with newspapers from the IT world. You can view my <a href="https://aleksalav.github.io/portfolio-Web-developer-Aleksa-Stosic/" target="_blank">CV </a> here.</p>
<div class="col-12 d-flex justify-content-center align-item-center">
<button><a href="models/exportWord.php">export word</a>
</button>
</div>
</div>
</div>
