<?php

require_once "models/dohvatiPostove/functions.php";?>
<div class="col-lg-12 pt-5 pb-5"></div>
<div class="col-lg-12 pt-5 pb-5"></div>
<div class="col-lg-12 pt-3 text-white pb-5">

<?php
if(isset($_GET["IDPost"])):
    $id=$_GET["IDPost"];

    $post = dohvatiPost($id);
?>

        <form id="FormaUpdate" action="models/updatePost.php" method="post" enctype="multipart/form-data">
            <h2 class="section-subheading text-muted text-center">Update</h2>
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <h2 class="text-danger">
                    <?php 
                        if(isset($_SESSION['uspesnoUpdatePost'])){
                                
                                if($_SESSION['uspesnoUpdatePost']){
                                    echo "You have successfully updated!";
                                }
                                else{
                                    echo "An error has occurred try again!";
                                }
                        }
                        else{
                            echo "";
                        }
                    ?>
                    </h2>
                    <div >
                        <input type="hidden" value="<?=$id?>" name="id" class="form-control"/>
                    </div>
                    <div >
                    <label class="text-dark">title:</label>
                        <input type="text" value="<?=$post->naslov?>" name="title" class="form-control"/>
                    </div>
                    <div >
                    <label class="text-dark">subtilte:</label>
                        <input type="text" value="<?=$post->podnaslov?>" name="subtitle" class="form-control"/>
                    </div>
                    <div >
                    <label class="text-dark">text title:</label>
                    <textarea  name="text" class="form-control"><?=$post->text?></textarea>
                    </div>
                    <div >
                    <label class="text-dark">text subtilte:</label>
                        <textarea  name="textsubtitle" class="form-control"><?=$post->text_podnaslov?></textarea>
                    </div>
                   
                    <div >
                    </div>
                  
                    <div >
                    </div>

                    <div class="clearfix"></div>
                    <div class="col-lg-12 text-center">
                        <div id="success"></div>
                        <input type="submit" id="updatuj" name="updatuj" class="btn btn-primary btn-xl text-uppercase"
                            value="Update" />
                    </div>
                </div>
        </form>
        <?php elseif(!isset($_GET["IDPost"])):?>
            <form id="FormaUpdate" action="models/updatePost.php" method="post" enctype="multipart/form-data">
            <h2 class="section-subheading text-muted text-center">Update</h2>
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <h2 class="text-danger">
                    <?php 
                        if(isset($_SESSION['uspesnoUpdatePost'])){
                                
                                if($_SESSION['uspesnoUpdatePost']){
                                    echo "You have successfully updated the post!";
                                }
                                else{
                                    echo "An error has occurred try again!";
                                }
                        }
                        else{
                            echo "";
                        }
                    ?>
                    </h2>
                    <div >
                        <input type="hidden" value="<?=$id?>" name="id" class="form-control"/>
                    </div>
                    <div >
                    <label class="text-dark">title:</label>
                        <input type="text" value="" name="title" class="form-control"/>
                    </div>
                    <div >
                    <label class="text-dark">subtilte:</label>
                        <input type="text" value="" name="subtitle" class="form-control"/>
                    </div>
                    <div >
                    <label class="text-dark">text title:</label>
                    <textarea  name="text" class="form-control"></textarea>
                    </div>
                    <div >
                    <label class="text-dark">text subtilte:</label>
                        <textarea  name="textsubtitle" class="form-control"></textarea>
                    </div>
              
                    <div >
                    </div>
                   
                    <div >
                    </div>

                    <div class="clearfix"></div>
                    <div class="col-lg-12 text-center">
                        <div id="success"></div>
                        <input type="submit" id="updatuj" name="updatuj" class="btn btn-primary btn-xl text-uppercase"
                            value="Update" />
                    </div>
                </div>
        </form>
                    <?php endif; unset($_SESSION['uspesnoUpdatePost']);?>
    </div>
    <div class="col-lg-12 pt-5 pb-5"></div>
<div class="col-lg-12 pt-5 pb-5"></div>
    