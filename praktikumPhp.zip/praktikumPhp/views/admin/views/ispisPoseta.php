<?php
require_once "../../config/connection.php";
require_once "models/statistika/functions.php";


if (isset($_SESSION['korisnik']) && $_SESSION['korisnik']->naziv == 'admin') : ?>
    <div class="container table-responsive">
    <div class="row">
        <div class="col-lg-12 text-center">
            <h1>Site visits in the last 24 h</h1>
        </div>
    </div>
        <table class="table table-bordered table-striped">
            <?php
            $sveStranice = sveStranice();
            $brojStranica = count($sveStranice);
            ?>
            <thead class="thead-light">
                <tr>
                    <?php foreach ($sveStranice as $item) : ?>
                        <th scope="col"><?= $item; ?></th>
                    <?php endforeach; ?>
                </tr>
                <tr>
                    <?php foreach (procenatPrisupaPoStranici() as $item) : ?>
                        <td><?= $item; ?>%</td>
                    <?php endforeach; ?>
                </tr>
            </thead>
        </table>
        <div class="row">
            <div class="col-lg-12 text-center">
                Logged in users: <?= ukupnoPrijavljeniKorisnici(); ?>
            </div>
        </div>
    </div>
<?php endif; ?>