<h2 class="col-12 d-flex justify-content-center pt-5">POST</h2>
<div class="col-12 d-flex justify-content-center pt-5">

<form name="" id="" action="models/addPost.php" method="post" enctype="multipart/form-data">
					<div id="success" class=" text-danger">
						<?php 
							if(isset($_SESSION['errorUploadImg'])){
								foreach( $_SESSION['errorUploadImg'] as $i ){
									echo $i."<br>";
								}
								unset($_SESSION['errorUploadImg']);
							}
						?>
						</div>
						<!-- For success/fail messages -->
						<div class="control-group form-group">
							<div class="controls">
								<input type="text" placeholder="title" class="form-control" id="title" name="title" required data-validation-required-message="Please enter the title.">
								<p class="help-block"></p>
                            </div> 
						</div>
						<div class="control-group form-group">
							<div class="controls">
								<textarea rows="5" cols="100" placeholder="content" class="form-control" id="text" name="text" required data-validation-required-message="Please enter text" maxlength="999" style="resize:none"></textarea>
							</div>
						</div>
                         <!-- FORMA ZA UNOS SLIKA -->
                <div class="control-group form-group">
                    <div class="controls">
                        <label>photo(s): </label>
                        <input type="file" name="userfile[]" class="form-control" multiple="multiple"/>
                        
                    </div>
                <!--// FORMA ZA UNOS SLIKA -->
                    </div>
                    <div class="control-group form-group">
							<div class="controls">
								<input type="text" placeholder="subtitle" class="form-control" id="subtitle" name="subtitle">
								<p class="help-block"></p>
                            </div> 
						</div>
						<div class="control-group form-group">
							<div class="controls">
								<textarea rows="5" cols="100" placeholder="content for subtext" class="form-control" id="subtext" name="subtext"  maxlength="999" style="resize:none"></textarea>
							</div>
						</div>

	
						<button type="submit" class="btn btn-primary" id="send" name="send">Upload post</button>
					</form>
</div>

