<div class="container-fluid d-flex justify-content-center">
<table class="table table-stripped table-bordered table-hover">
            <thead>
                <tr>
                    <th>title</th>
                    <th>Text</th>
                    <!-- <th>ID kategorije</th> -->
                    <th>subtitle</th>
                    <th>text subtitle</th>
                    <th>date</th>
                    <th>update</th>
                    <th>delete</th>
                </tr>
            </thead>
            <?php

       require_once "models/dohvatiPostove/functions.php";
                         $postovi = dohvatiPostove();
                        foreach($postovi['posts'] as $p):
                    ?>
            <tbody>
                <tr>
                    <td class="align-middle"><?= $p->naslov?></td>
                    <td class="align-middle"><?= $p->text?></td>
                    <td class="align-middle"><?= $p->podnaslov?></td>
                    <td class="align-middle"><?= $p->text_podnaslov?></td>
                    <td class="align-middle"><?= $p->datum?></td>
                    <td class="align-middle"><a href="admin.php?page=fillForm&IDPost=<?= $p->idPost?>" class="btn btn-secondary pokupiIdUpdate">update</a></td>
                    <td class="align-middle"><a href="models/delete.php?IDPost=<?= $p->idPost?>" class="btn btn-secondary pokupiIdUpdate">delete</a></td>
                </tr>
            </tbody>
            <?php endforeach;?>
        </table>
</div>
