<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="">
	<meta name="author" content="">
	<title> Zonebiz - Business Consulting Bootstrap4 Responsive Template </title>
	<!-- Bootstrap core CSS -->
	<link href="../../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	<!-- Fontawesome CSS -->
	<link href="../../assets/css/all.css" rel="stylesheet">
	<!-- Owl Carousel CSS -->
	<link href="../../assets/css/owl.carousel.min.css" rel="stylesheet">
	<!-- Owl Carousel CSS -->
	<link href="../../assets/css/jquery.fancybox.min.css" rel="stylesheet">
	<!-- Custom styles for this template -->
	<link href="../../assets/css/style.css" rel="stylesheet" type="text/css"/>
	<link href="../../assets/css/mojCss.css" rel="stylesheet" type="text/css"/>
</head>

<body>
<div class="wrapper-main">
<?php include "models/meni.php";?>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-light top-nav">
        <div class="container-fluid bg-dark">
		<a class="navbar-brand" href="index.html">
				<!-- <img src="../../assets/images/logo.png" alt="logo" /> -->
				<h2>United Against Poverty</h2>
            </a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
				<span class="text-white fas fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
				<ul class="navbar-nav ml-auto">
                
					<?php foreach($izvrsi as $item): ?>
					<li class="nav-item">
						<a class="nav-link text-white" href="<?=$item->href?>"><?=$item->naziv?></a>	
					</li>
					<?php endforeach; ?>
					
				</li>
                </ul>
            </div>
        </div>
	</nav>
	<!--Modal box-->
<div>