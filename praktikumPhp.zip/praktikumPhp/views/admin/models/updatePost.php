<?php
ob_start();
session_start();
    if(isset($_POST['updatuj'])){
        $id = $_POST['id'];
        $naslov = $_POST['title'];
        $podnaslov = $_POST['subtitle'];
        $textNaslov = $_POST['text'];
        $textsubtitle = $_POST['textsubtitle'];
            include "../../../config/connection.php";
            $pripremaUpdatePost=$conn->prepare("UPDATE  post set naslov=?, text=?, podnaslov=?, text_podnaslov=? where idPost=?");
            $pripremaUpdatePost->execute([$naslov,$textNaslov,$podnaslov,$textsubtitle,$id]);
            if($pripremaUpdatePost){
                $_SESSION['uspesnoUpdatePost']=true;
                header("Location: ../admin.php?page=fillForm");
            }else{
                $_SESSION['uspesnoUpdatePost']=false;
                header("Location: ../admin.php?page=fillForm");
            }
            
         
    }
?>