<?php
ob_start();
session_start();
if(isset($_POST["send"])) {
    $slike[] = $_FILES["userfile"];
    $total = count($_FILES['userfile']['name']);
    $maxSize= 104857600; //50mb
    $acceptable = array(
        'image/jpeg',
        'image/jpg',
        'image/jfif',
        'image/png'
    );
    /////////
    $fileName=[];
     $tmpFilePath=[];
     $sizeFile=[];
     $typeFile=[];
    for($i=0; $i<$total; $i++){
        $fileName[]= $_FILES['userfile']['name'][$i];
        $tmpFilePath[]= $_FILES['userfile']['tmp_name'][$i];
        $sizeFile[]= $_FILES['userfile']['size'][$i];
        $typeFile[]= $_FILES['userfile']['type'][$i];
    }
    ////////////
for($i=0; $i<$total; $i++){
        if($total>2){
            $error[] = 'Allowed is max 2 files.';
        }
        if(( $sizeFile[$i] >= $maxSize) || ($sizeFile[$i]== 0)) {
            $error[] = 'Some  file is too large. File must be less than 50 megabytes.';
        }

        if(!in_array($typeFile[$i], $acceptable) && (!empty($typeFile[$i]))) {
        $error[] = 'Invalid file type. Only JPG, GIF and PNG types are accepted.';
        }
        
}
    $errors=array_unique($error);

    /////////////
    $title=$_POST["title"];
    $text=$_POST["text"];
    $subtitle=$_POST["subtitle"];
    $subtext=$_POST["subtext"];
    include "../../../config/connection.php";
    $pripremaUnosaParamZaPost=$conn->prepare("INSERT INTO  post (`idPost`, `naslov`, `text`, `podnaslov`, `text_podnaslov`)  values (null,:naslov,:textPosta, :podnaslov,:podnaslov_text)");
    $pripremaUnosaParamZaPost->bindParam(":naslov",$title);
    $pripremaUnosaParamZaPost->bindParam(":textPosta",$text);
    $pripremaUnosaParamZaPost->bindParam(":podnaslov",$subtitle);
    $pripremaUnosaParamZaPost->bindParam(":podnaslov_text",$subtext);
    ////////////
  
    $novePutanje=[];
    for($i=0; $i<$total; $i++){
        $novePutanje[] = "../assets/imagesBefore/".$fileName[$i];
    }
    $uploaded=[];
    if(count($errors) === 0) {
        for($i=0; $i<$total; $i++){
            $uploaded[]=move_uploaded_file($tmpFilePath[$i], $novePutanje[$i]);
        }
    }
    else{
        $_SESSION["errorUploadImg"]=$errors;
        die(header("Location: ../admin.php?page=addPost")); 
    }
    $dimenzije=[];
    $sirina=[];
    $visina=[];
    for($i=0; $i<$total; $i++){
        $dimenzije[] = getimagesize($novePutanje[$i]);
        $sirina[] = $dimenzije[$i][0];
        $visina[] = $dimenzije[$i][1];
    }
  

    $novaSirina = 500;
   
     $novaVisina=[];
     for($i=0; $i<$total; $i++){
        $novaVisina[] = $visina[$i] / ($sirina[$i] / $novaSirina);
     }

 
    $ekstenzija=[];
    for($i=0; $i<$total; $i++){
         $ekstenzija[] = pathinfo($novePutanje[$i], PATHINFO_EXTENSION);
    }

    $noviNazivi=[];
    for($i=0; $i<$total; $i++){
        $noviNazivi[] = time()."_".$fileName[$i];
    }
    $uploadedSlika=[];
    $platno=[];
    for($i=0; $i<$total; $i++){
        if($ekstenzija[$i] == "jpg" || $ekstenzija[$i] == "jfif") {
            $uploadedSlika[] = imagecreatefromjpeg($novePutanje[$i]); 
            $platno[] = imagecreatetruecolor($novaSirina, $novaVisina[$i]);
            imagecopyresampled($platno[$i], $uploadedSlika[$i], 0, 0, 0, 0, $novaSirina, $novaVisina[$i], $sirina[$i], $visina[$i]);

            imagejpeg($platno[$i], "../assets/imagesAfter/".$noviNazivi[$i]);
        }
        else if($ekstenzija[$i] == "png"){ // PNG
            $uploadedSlika[] = imagecreatefrompng($novePutanje[$i]);
            $platno[] = imagecreatetruecolor($novaSirina, $novaVisina[$i]);
            imagecopyresampled($platno[$i], $uploadedSlika[$i], 0, 0, 0, 0, $novaSirina, $novaVisina[$i], $sirina[$i], $visina[$i]);

            imagepng($platno[$i], "../assets/imagesAfter/".$noviNazivi[$i]);
        }
       
    }
       

        try {
            $conn->beginTransaction();
            $pripremaUnosaParamZaPost->execute();
            $poslednjiDodat = $conn->lastInsertId();
            for($i=0; $i<$total; $i++){
            $pripremaUnosSlike = $conn->prepare("INSERT INTO  slika_post values (null,:nazivSlike,:idPost)");
            $pripremaUnosSlike->bindParam(":nazivSlike", $noviNazivi[$i]);
            $pripremaUnosSlike->bindParam(":idPost", $poslednjiDodat);
            $pripremaUnosSlike->execute();
            }
            $conn->commit();
            
            $code=202;
           
        } catch (PDOException $e) {
            $conn->rollback();
           $code = 409;
            echo $e->getMessage();
        }
        header("Location: ../admin.php?page=addPost");
       
}
