<?php

    function dohvatiPost($id){
        global $conn;

        $upit = "SELECT p.idPost,p.naslov,p.text,p.datum,p.podnaslov,p.text_podnaslov,(SELECT GROUP_CONCAT(s.naziv SEPARATOR '////') FROM slika_post s where p.idPost=s.idPost) as 'slike' FROM post p WHERE p.idPost = ?";

        $priprema = $conn->prepare($upit);
        $priprema->execute([$id]);
        return $priprema->fetch();
    }

    function dohvatiPostove(){
        
        global $conn;

        $upit = "SELECT p.idPost,p.naslov,p.text,p.datum,p.podnaslov,p.text_podnaslov,(SELECT GROUP_CONCAT(s.naziv SEPARATOR '////') FROM slika_post s where p.idPost=s.idPost) as 'slike' FROM post p ";
    
        $posts = $conn->query($upit)->fetchAll();
        $SviPostovi=$conn->query("SELECT * from post")->fetchAll();
         $komentarIspis= $conn->query("SELECT * from korisnik k inner join postkomentar_korisnik pkk on k.idKorisnik=pkk.idKorisnik inner join post_komentar pk on pkk.idPostKomentar=pk.idPostKomentar inner join komentari kom on pk.idKomentar=kom.idKomentar");
         $kontakt=$conn->query("SELECT * from kontakt_forma")->fetchAll();

         return ["posts"=>$posts,"komentarIspis"=>$komentarIspis,"SviPostovi"=>$SviPostovi,"kontakt"=>$kontakt];
    }
    function parsiranjeSlika($element){
        if(strrpos($element,"////")==true){
        $result= explode("////",$element);
           return $result[0];}
        else {
            return $element;
        }
   }
    function parsiranjeSlikaPodnaslov($element){
        if(strrpos($element,"////")==true){
            $result= explode("////",$element);
               return $result[1];}
            else {
                return false;
            }
    }
    function dohvatiIdSlikeZaNaslov($element){
        global $conn;

        $upit = "SELECT * FROM slika_post  where naziv = ?";

        $priprema = $conn->prepare($upit);
        $priprema->execute([$element]);
        return $priprema->fetch();
    }
?>