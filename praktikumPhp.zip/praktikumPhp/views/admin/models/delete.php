<?php 
    include "../../../config/connection.php";
    if(isset($_GET['IDPost'])){

        $id = $_GET['IDPost'];
        
      

        $upit0 = "DELETE FROM post WHERE idPost = ?";
        $priprema=$conn->prepare($upit0);
   
        try {
            $conn->beginTransaction();
            $priprema->execute([$id]);
            
            $conn->commit();
            header("Location: ../admin.php?page=posts");
            } catch (PDOException $e) {
            $conn->rollBack();
            echo "<h1>Server error, please try again!</h1>";
            echo $e->getMessage();
        }
    }