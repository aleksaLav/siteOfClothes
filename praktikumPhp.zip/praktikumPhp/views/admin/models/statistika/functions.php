<?php
	
	 function sveStranice()
	 {
		 return
			 ["home", "blog", "about", "author", "contact", "registration", "Profile Picture"];
	 }
	 
	 function procenatPrisupaPoStranici()
	 {
		 $niz = [];
		 $suma = 0;
		 $home = 0;
		 $blog = 0;
		 $about = 0;
		 $author = 0;
		 $contact = 0;
		 $registration = 0;
	
		 $profilePicture = 0;
		 $oneDayAgo = strtotime("1 day ago");
	 
		 
		 $file = file(LOG_FAJL);

		 if (count($file)) {
			 foreach ($file as $item) {
				 $delovi = explode("\t", $item);
				 $url = explode(".php", $delovi[0]);
				 if(strpos(@$url[1],"&")){
					 $strana = explode("&",$url[1])[0];
				 }
				 else{
					 @$strana = $url[1];
				 }
				 if (strtotime(@$delovi[2]) >= $oneDayAgo) {
					 switch ($strana) {
						 case "":
							 $home++;
							 $suma++;;
							 break;
						 case "?page=home":
							 $home++;
							 $suma++;;
							 break;
						 case "?page=blog":
							 $blog++;
							 $suma++;;
							 break;
						 case "?page=faq":
							 $about++;
							 $suma++;;
							 break;
						 case "?page=registr":
							 $registration++;
							 $suma++;;
							 break;
						 case "?page=contact":
							 $contact++;
							 $suma++;;
							 break;
						 case "?page=profil":
							 $profilePicture++;
							 $suma++;;
							 break;
						case "?page=author":
							$author++;
							$suma++;;
						break;
						 default:
							 $home++;
							 $suma++;;
							 break;
					 }
				 }
			 }
			 if ($suma > 0) {
				 $niz[] = round($home * 100 / $suma, 2);
				 $niz[] = round($author * 100 / $suma, 2);
				 $niz[] = round($contact * 100 / $suma, 2);
				 $niz[] = round($registration * 100 / $suma, 2);
				 $niz[] = round($blog * 100 / $suma, 2);
				 $niz[] = round($about * 100 / $suma, 2);
				 $niz[] = round($profilePicture * 100 / $suma, 2);
			 }
		 }
		 return $niz;
	 }
	 
	 function zabeleziLogovanjeUfajlLogovanje($id)
	 {
		 @$file = fopen(LOGOVANJE_FAJL, "a");
		 $input = $id . "\n";
		 @fwrite($file, $input);
		 @fclose($file);
	 }
	 function ukupnoPrijavljeniKorisnici()
	 {
		 return count(file(LOGOVANJE_FAJL));
	 }
	 
	 function obrisiIzFajlaLogovanje($id)
	 {
		 $id = (int) $id;
		 $input = "";
		 @$file = file(LOGOVANJE_FAJL);
		 if (count($file)) {
			 foreach ($file as $item) {
				 $idInFile = trim((int) $item);
				 if ($idInFile != $id) {
					 $input .= $idInFile . "\n";
				 }
			 }
		 }
		 @$file = fopen(LOGOVANJE_FAJL, "w");
		 @fwrite($file, $input);
		 @fclose($file);
	 }
?>



