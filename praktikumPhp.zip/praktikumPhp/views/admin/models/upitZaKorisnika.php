<?php 
  // include "../../../config/connection.php";

$upit = "SELECT * from korisnik";
$korisnik = $conn->query($upit)->fetchAll();
?>