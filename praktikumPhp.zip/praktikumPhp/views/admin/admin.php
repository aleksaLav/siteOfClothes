<?php
include "../../config/connection.php";
session_start();
if(isset($_SESSION['korisnik']) && $_SESSION['korisnik']->naziv=="user" || !isset($_SESSION['korisnik'])){
    header("Location: ../../index.php");
}
?>
<?php require "views/fixed/nav.php";?>

<?php 
if(isset($_GET['page'])){
    $page = $_GET['page'];
    switch($page){
        case "addPost":
        require   "views/dodajPost.php";
        break;
        case "users":
        require   "views/tabelaKorisnik.php";
        break;
        case "posts":
        require   "views/ispisIUpdatePostova.php";
        break;
        case "fillForm":
            require   "views/popuniFormuPostom.php";
            break;
        case "contact":
        require   "views/ispisiContact.php";
        break;
        case "visits":
            require   "views/ispisPoseta.php";
            break;
    }
}
?>
<?php require "views/fixed/footer.php";?>