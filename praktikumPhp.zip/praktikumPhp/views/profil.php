  <!-- FORMA ZA UNOS SLIKA -->
  <div class="container-fluid d-flex justify-content-center align-items-center">
  <form action="models/add-image.php" method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <label>Photo: </label>
                    </div>
                    <div class="row">
                        <input type="file" name="slika" class="form-control"/>
                    </div>
                    <div class="row pt-5">
                        <input type="submit" name="dugme" value="Upload file" class="btn btn-primary"/>
                    </div>
                </form>
                <!--// FORMA ZA UNOS SLIKA -->
  </div>
 