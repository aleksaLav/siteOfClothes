<!-- full Title -->
<div class="full-title">
		<div class="container">
			<!-- Page Heading/Breadcrumbs -->
			<h1 class="mt-4 mb-3"> Contact </h1>
			<div class="breadcrumb-main">
				<ol class="breadcrumb">
					<li class="breadcrumb-item">
						<a href="index.php">Home</a>
					</li>
					<li class="breadcrumb-item active">Contact</li>
				</ol>
			</div>
		</div>
	</div>

    <div class="contact-main">
		<div class="error col-12 d-flex justify-content-center" id="error-contact">

		</div>
		<div class="container">
			<!-- Content Row -->
		  <div class="row">
			<!-- Map Column -->
				<div class="col-lg-8 mb-4 contact-left">
					<h3>Send us a Message</h3>
					<!-- <form name="sentMessage" id="contactForm" action="models/kontaktForma.php" method="post"> -->
						<div class="control-group form-group">
							<div class="controls">
								<p id="error-name" class="text-danger"></p>
								<input type="text" placeholder="Full Name" class="form-control" id="name" name="name" required data-validation-required-message="Please enter your name.">
								<p class="help-block">The full Name must start with an uppercase letter, and the rest lowercase, the user can have multiple names, the name must contain min 2 , max 14 characters.</p>
							</div>
						</div>
						<div class="control-group form-group">
							<div class="controls">
								<p id="error-phone" class="text-danger"></p>
								<input type="tel" placeholder="Phone Number" class="form-control" id="phone" name="phone" required data-validation-required-message="Please enter your phone number.">
								<p class="help-block">An example of the correct telephone numbers: 06x xxx xxx(x) or +3816x xxx xxx(x) </p>
							</div>
						</div>
						<div class="control-group form-group">
							<div class="controls">
								<p id="error-email" class="text-danger"></p>	
								<input type="email" placeholder="Email Address" class="form-control" id="email" name="email" required data-validation-required-message="Please enter your email address.">
								<p class="help-block">Email address must contain an @ tag, example of email format: example -@gmail.com</p>
							</div>
						</div>
						<div class="control-group form-group">
							<div class="controls">
								<p id="error-message" class="text-danger"></p>
								<textarea rows="5" cols="100" placeholder="Message" class="form-control" id="message" name="message" required data-validation-required-message="Please enter your message" maxlength="999" style="resize:none"></textarea>
								<p class="help-block">The message must contain a minimum of 15 and a maximum of 99 characters</p>
							</div>
						</div>
						<div id="success"></div>
						<!-- For success/fail messages -->
						<button  class="btn btn-primary" id="sendMessage" name="sendMessageButton">Send Message</button>
					<!-- </form> -->
				</div>
				<!-- Contact Details Column -->
				<div class="col-lg-4 mb-4 contact-right">
					<h3>Contact Details</h3>
					<p>
						3481 Melrose Place
						<br>Beverly Hills, CA 90210
						<br>
					</p>
					<p>
						<abbr title="Phone">P</abbr>: (123) 456-7890
					</p>
					<p>
						<abbr title="Email">E</abbr>:
						<a href="mailto:name@example.com"> name@example.com </a>
					</p>
					<p>
						<abbr title="Hours">H</abbr>: Monday - Friday: 9:00 AM to 5:00 PM
					</p>
				</div>
			</div>
			<!-- /.row -->
		</div>
		<!-- /.container -->
	</div>
	