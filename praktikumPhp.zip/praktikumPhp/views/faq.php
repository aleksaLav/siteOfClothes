<!-- full Title -->
<div class="full-title">
		<div class="container">
			<!-- Page Heading/Breadcrumbs -->
			<h1 class="mt-4 mb-3">FAQ</h1>
			<div class="breadcrumb-main">
				<ol class="breadcrumb">
					<li class="breadcrumb-item">
						<a href="index.php">Home</a>
					</li>
					<li class="breadcrumb-item active">FAQ</li>
				</ol>
			</div>
		</div>
	</div>
	
    <!-- Page Content -->
	<div class="faq-main">
		<div class="container">
			<h2>Frequently Asked Questions</h2>
			<div class="accordion" id="accordionExample">				
				<div class="card accordion-single">
					<div class="card-header" id="1">
						<h5 class="mb-0">
							<button class="btn btn-link" type="button" data-toggle="collapse"
								data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
								Our mission
							</button>
						</h5>
					</div>
					<div id="collapseOne" class="collapse show" data-parent="#accordionExample">
						<div class="card-body">
						The mission of Charity organization Serbs for Serbs is to affect on consciousness of Serbian people through our projects and humanitarian activities, in order to develop better society for future generations.
						</div>
					</div>
				</div>
				<div class="card accordion-single">
					<div class="card-header" id="2">
						<h5 class="mb-0">
							<button class="btn btn-link collapsed" type="button" data-toggle="collapse"
								data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
								Why United Against Poverty?
							</button>
						</h5>
					</div>
					<div id="collapseTwo" class="collapse" data-parent="#accordionExample">
						<div class="card-body">
						We wanted to alleviate impaired spirit of Serbian people in togetherness and brotherhood help through humanitarian work and social aid.
						</div>
					</div>
				</div>
				<div class="card accordion-single">
					<div class="card-header" id="3">
						<h5 class="mb-0">
							<button class="btn btn-link collapsed" type="button" data-toggle="collapse"
								data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
								Who do we help?
							</button>
						</h5>
					</div>
					<div id="collapseThree" class="collapse" data-parent="#accordionExample">
						<div class="card-body">
						We help Serbian families who live in the Balkans, have four or more children and live in terrible poverty.
						</div>
					</div>
				</div>
				<div class="card accordion-single">
					<div class="card-header">
						<h5 class="mb-0">
							<button class="btn btn-link collapsed" type="button" data-toggle="collapse"
								data-target="#c4" aria-expanded="false" aria-controls="collapseThree">
								Why do we help?
							</button>
						</h5>
					</div>
					<div id="c4" class="collapse" data-parent="#accordionExample">
						<div class="card-body">
						We believe that there is a basic need for one human (or a group) to help others in distress. A help is not only human virtue but also a Christian responsibility. By focusing our help on families with many children, we directly affect on their stirring toward becoming independent from social-dependable government programs. Indirectly, we want to affect on birth rate of Serbian people that has been in great decline in last 20 years.
						</div>
					</div>
				</div>
				<div class="card accordion-single">
					<div class="card-header">
						<h5 class="mb-0">
							<button class="btn btn-link collapsed" type="button" data-toggle="collapse"
								data-target="#c5" aria-expanded="false" aria-controls="collapseThree">
								Who do we need in organization?
							</button>
						</h5>
					</div>
					<div id="c5" class="collapse" data-parent="#accordionExample">
						<div class="card-body">
						We need members, volunteers and donors that will secure financial stability through supporting our programs and activities in the future. Donors may join our daily activities within the organization in order to coordinate our work better. We also need volunteers ready to donate several hours per week for actual work within the organization. Activities of volunteers and their specific tasks would be determined by the required projects and their personal interest. From that group of volunteers we would look for future leaders of organization.
						</div>
					</div>
				</div>
			</div>
		</div>
    </div>
    <!-- /.container -->
	