<?php
 include "models/dohvatiPostove/functions.php";

 if(isset($_GET['postId'])){
	$idPost=$_GET['postId'];
 }
if (isset($_SESSION['postFilter'])) {
	$postFilter = $_SESSION['postFilter'];
}else{
	$postFilter = null;
}
if(isset($_SESSION['newerOlder'])){
	$postFilter=$_SESSION['newerOlder'];
}
?>
	<!-- full Title -->
	<div class="full-title">
		<div class="container">
			<!-- Page Heading/Breadcrumbs -->
			<h1 class="mt-4 mb-3"> Blog </h1>
			<div class="breadcrumb-main">
				<ol class="breadcrumb">
					<li class="breadcrumb-item">
						<a href="index.php">Home</a>
					</li>
					<li class="breadcrumb-item active">Blog</li>
				</ol>
			</div>
		</div>
	</div>

    <div class="blog-main">
		<div class="container">
			<div class="row">
				<!-- Blog Entries Column -->
				<div class="col-md-8 blog-entries" id="posts">
					<!-- Blog Post -->
					<?php
						$postovi = dohvatiPostove();
						
					
						if(isset($_GET['postId'])): 
						
						foreach ($postovi['posts'] as $item):	
						if($item->idPost ==$idPost):
						?>

						<div class="card mb-4">
						<img class="card-img-top" src="views/admin/assets/imagesAfter/<?= parsiranjeSlika($item->slike); ?>" alt="<?=parsiranjeSlika($item->slike);?>" />
						<div class="card-body">
							<div class="by-post">
								Posted on <?= $item->datum ?> by <a href="#">UAP</a>
							</div>
							<h2 class="card-title"><?= $item->naslov ?></h2>
							<p class="card-text"><?= $item->text ?></p>
						</div>

						<div class="card mb-4">
						
							<div class="card-body">
							
								<?php if(strrpos($item->slike,"////")==true && $item->text_podnaslov!="" && $item->podnaslov!=""): ?>
								<h2 class="card-title"><?= $item->podnaslov ?></h2>
								<img class="card-img-top" src="views/admin/assets/imagesAfter/<?= parsiranjeSlikaPodnaslov($item->slike); ?>" alt="<?=parsiranjeSlikaPodnaslov($item->slike);?>" />
								<p class="card-text"><?= $item->text_podnaslov ?></p>
								<?php endif; if(strrpos($item->slike,"////")==false && $item->text_podnaslov!="" && $item->podnaslov!=""): ?>
								<h2 class="card-title"><?= $item->podnaslov ?></h2>
								<p class="card-text"><?= $item->text_podnaslov ?></p>
								<?php endif; if(strrpos($item->slike,"////")==true && $item->text_podnaslov!="" && $item->podnaslov==""): ?>
								<img class="card-img-top" src="views/admin/assets/imagesAfter/<?= parsiranjeSlikaPodnaslov($item->slike); ?>" alt="<?=parsiranjeSlikaPodnaslov($item->slike);?>" />
								<p class="card-text"><?= $item->text_podnaslov ?></p>
								<?php endif;  if(strrpos($item->slike,"////")==false && $item->text_podnaslov!="" && $item->podnaslov==""): ?>
								<p class="card-text"><?= $item->text_podnaslov ?></p>
								<?php endif;?>
							</div>
						</div>
						<hr>
				<div class="blog-right-side">
				<?php
				if((isset($_SESSION['korisnik']) && $_SESSION['korisnik']->naziv == "user")): ?>
					<!-- Comments Form -->
					<div class="card my-4">
						<h5 class="card-header">Leave a Comment:</h5>
						<div class="card-body">
							<form action="models/upisiKomentar.php" method="post">
								<div class="form-group">
									<textarea class="form-control" name="textComment" rows="3"></textarea>
									<input type="hidden" name="idPost" value="<?= $idPost ?>">
									<input type="hidden" name="stranica" value="<?= isset($_GET['stranica'])?$_GET['stranica']:1; ?>">
								</div>
								<button type="submit" name="sendComment" class="btn btn-primary">Submit</button>
							</form>
						</div>
					</div>
				<?php
				elseif(!(isset($_SESSION['korisnik']) && $_SESSION['korisnik']->naziv == "user")):
				?>
				<!-- Comments title -->
				<div class="card my-4">
						<h5 class="card-header">Log in to comment on the post</h5>
				</div>
				<?php
				endif;
				?>
					<!-- end Comments title -->
				</div>
				
				
				<?php 
				foreach ($postovi['komentarIspis'] as $item):
				if($item->idPost ==$idPost):	?>
					<div class="media mb-4">
					 <img class="d-flex mr-3 rounded-circle" src="assets/litleProfilImage/<?=$item->slikaNaziv?>" alt="<?=$item->slikaNaziv?>">
					<div class="media-body">
							<h5 class="mt-0"><?=$item->korisnickoIme?></h5>
							<?=$item->komentar?>						
					</div> 
					</div>
				<?php 
				endif;
				endforeach;	?>
			
				
					</div>
					<?php
						endif;
						endforeach;
						elseif(!isset($_GET['postId']) && $postFilter==null):
						
						foreach ($postovi['posts'] as $item):
					?>
					<div class="card mb-4">
						<img class="card-img-top" src="views/admin/assets/imagesAfter/<?= parsiranjeSlika($item->slike); ?>" alt="<?=parsiranjeSlika($item->slike);?>" />
						<div class="card-body">
							<div class="by-post">
								Posted on <?= $item->datum ?> by <a href="#">UAP</a>
							</div>
							<h2 class="card-title"><?= $item->naslov ?></h2>
							<p class="card-text"><?= substr($item->text,0,120); ?></p>
							<a href="index.php?page=blog&stranica=<?php  
							$brojac=1;
							foreach($postovi['SviPostovi'] as $i){
							if($i->idPost==$item->idPost){
							break;}
							$brojac++;
							}
							$stranica=ceil($brojac/2);
							echo $stranica; ?>&postId=<?= $item->idPost ?>"class="btn btn-primary">Continue &rarr;</a>
						</div>
					</div>
						<?php endforeach; 
						elseif(!isset($_GET['postId']) && count($postFilter)>0):
						
						foreach ($postFilter as $item):
					?>
					<div class="card mb-4">
						<img class="card-img-top" src="views/admin/assets/imagesAfter/<?= parsiranjeSlika($item->slike); ?>" alt="<?=parsiranjeSlika($item->slike);?>" />
						<div class="card-body">
							<div class="by-post">
								Posted on <?= $item->datum ?> by <a href="#">UAP</a>
							</div>
							<h2 class="card-title"><?= $item->naslov ?></h2>
							<p class="card-text"><?= substr($item->text,0,120); ?></p>
							<a href="index.php?page=blog&stranica=<?php  
							$brojac=1;
							foreach($postovi['SviPostovi'] as $i){
							if($i->idPost==$item->idPost){
							break;}
							$brojac++;
							}
							$stranica=ceil($brojac/2);
							echo $stranica; ?>&postId=<?= $item->idPost?>"class="btn btn-primary ">Continue &rarr;</a>
						</div>
					</div>
						<?php endforeach; endif;?>
					<div class="pagination_bar_arrow" id="pagination">
					<?php
						if(!isset($_SESSION['pretraga'])):
							$stranica = isset($_GET['stranica'])?$_GET['stranica']:1;
							for($i=1;$i<=$postovi["brojPostova"];$i++):
						?>
						<a href="index.php?page=blog&stranica=<?= $i?>" class="btn btn-primary btn-outline <?= ($stranica == $i) ?>"><?= $i?></a>
						<?php
							endfor;
						endif;
						unset($_SESSION['pretraga']);
						?>
					</div>
				</div>
				<!-- Sidebar Widgets Column -->
				<div class="col-md-4 blog-right-side">
					<!-- Search Widget -->
					<?php if(!isset($_GET["postId"])): ?>
					<div class="card mb-4">
						<h5 class="card-header">Search</h5>
						<div class="card-body">
							<div class="input-group">
							<!-- <form action="" method="post"> -->
								<input type="text" name="naslovIzPretrage" id="naslovIzPretrage" class="form-control" placeholder="Search for...">
								<span class="input-group-btn">
									<button class="btn btn-secondary" id="pretraga" name="pretraga">Go!</button>
								</span>
							<!-- </form> -->
							</div>
						</div>
					</div>
					
					<!-- Categories Widget -->
					<div class="card my-4">
						<h5 class="card-header">sort by publication date</h5>
						<div class="card-body">
							<div class="row">
								<div class="col-lg-6">
								<form action="models/sortiranjePoDatumu.php" method="post">
									<ul class="list-unstyled mb-0">
										<li>
											<button class="btn btn-secondary"  name="newer" type="submit" id="newer">newer posts!</button>
										</li>
										<li>
											<button class="btn btn-secondary"  name="older" type="submit" id="older">older posts!</button> 
										</li>
									</ul>
								</form>
								</div>
							</div>
						</div>
					</div>
					<?php elseif(isset($_GET["postId"])): ?>
					<!-- Side Widget -->
					<div class="card my-4">
						<h5 class="card-header">Attention!</h5>
						<div class="card-body">
							To sort and search, you must return to the post page! You must also log in to your account to comment!
						</div>
					</div>
					<?php endif; ?>
				</div>
			</div>
			<!-- /.row -->
		</div>
		<!-- /.container -->
	</div>
	<?php unset($_SESSION['newerOlder']);
	unset($_SESSION['postFilter']);?>