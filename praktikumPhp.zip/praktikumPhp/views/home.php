<?php 
include "views/sliderHome.php";
include "views/contentHome.php";