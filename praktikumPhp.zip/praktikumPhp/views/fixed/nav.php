<?php include "models/meni.php";?>
<body>
<div class="wrapper-main">
	<!-- Top Bar -->
	<div class="top-bar">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="social-media">
						<ul>
							<li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
							<li><a href="#"><i class="fab fa-twitter"></i></a></li>
							<li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>
							<li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
							<li><a href="#"><i class="fab fa-instagram"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="contact-details">
						<ul>
							<li><i class="fas fa-phone fa-rotate-90"></i> +01 899 286 777</li>
							<li><i class="fas fa-map-marker-alt"></i> 8/99 , North khailkoir, NY</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-light top-nav">
        <div class="container">
            <a class="navbar-brand" href="index.html">
			<h2 class="text-dark">United Against Poverty</h2>
            </a>
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
				<span class="fas fa-bars"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
				<ul class="navbar-nav ml-auto">
				<?php 
				if(!(isset($_SESSION['korisnik']) && $_SESSION['korisnik']->naziv == "user")):
					foreach($izvrsi as $i):
						if($i->dropdown==0 && $i->href!=null):
				?>
					<li class="nav-item">
						<a class="nav-link" href="<?= $i->href?>"><?= $i->naziv?></a>
					</li>
				<?php 
					elseif($i->href==null):
				?>
				<li class="nav-item">
						<a class="nav-link" href="#" data-target="#login" data-toggle="modal"><?= $i->naziv?></a>
					</li>
				<?php 
						endif;
					endforeach;
				?>
					<li class="nav-item dropdown">
						<a class="nav-link" href="#" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Docs/Autor<i class="fas fa-sort-down"></i></a>
						<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
				<?php 
					foreach($izvrsi as $i):
						if($i->dropdown==1):
				?>
							<a class="dropdown-item" href="<?= $i->href?>"><?= $i->naziv?></a>
							<?php 
						endif;
					endforeach;
			elseif((isset($_SESSION['korisnik']) && $_SESSION['korisnik']->naziv == "user")): 
				foreach($izvrsi as $i):
              		if($i->naziv != "SIGN IN" && $i->dropdown==0 && $i->href!=null):
				?>
					<li class="nav-item">
						<a class="nav-link" href="<?= $i->href?>"><?= $i->naziv?></a>
					</li>
				<?php
					endif;
				endforeach;
				?>
				<li class="nav-item">
					<a class="nav-link" href="models/logout.php">log out</a>
				</li>
				<?php
				if($_SESSION['korisnik']->slikaNaziv==""):
				?>
				<li class="nav-item">
				<a class="nav-link" href="index.php?page=profil">
					<img src="assets/images/profilna.png" alt="profile picture"/>
				</a>
				</li>
				<?php 
					elseif($_SESSION['korisnik']->slikaNaziv!=""):
				?>
				<a class="nav-link" href="index.php?page=profil">
					<img src="assets/litleProfilImage/<?= $_SESSION['korisnik']->slikaNaziv?>" alt="profile picture"/>
				</a>
				</li>
				<?php 
						endif;
				?>
				<li class="nav-item dropdown">
						<a class="nav-link" href="#" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Docs/Autor<i class="fas fa-sort-down"></i></a>
						<div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
				<?php 
					foreach($izvrsi as $i):
						if($i->dropdown==1):
				?>
							<a class="dropdown-item" href="<?= $i->href?>"><?= $i->naziv?></a>
							<?php 
						endif;
					endforeach;
			endif;
				?>
					
						</div>
					</li>
				</ul>
            </div>
        </div>
	</nav>
	<!--Modal box-->
	<div class="modal fade" id="login" role="dialog">
    <div class="modal-dialog modal-sm">

      <!-- Modal content no 1-->
      <div class="modal-content">
        <div class="modal-header">
		<h4 class="modal-title text-left form-title">Login</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body padtrbl">

          <div class="login-box-body">
            <p class="login-box-msg">Sign in to start your session</p>
            <div class="form-group">
              <form name="" id="loginForm">
                <div class="form-group has-feedback">
                  <!----- username -------------->
                  <input class="form-control" placeholder="Username" id="loginid" type="text" autocomplete="off" />
                  <span style="display:none;font-weight:bold; position:absolute;color: red;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 27px; top: 5px;" id="span_loginid"></span>
                  <!---Alredy exists  ! -->
                  <span class="glyphicon glyphicon-user form-control-feedback"></span>
                </div>
                <div class="form-group has-feedback">
                  <!----- password -------------->
                  <input class="form-control" placeholder="Password" id="loginpsw" type="password" autocomplete="off" />
                  <span style="display:none;font-weight:bold; position:absolute;color: grey;position: absolute;padding:4px;font-size: 11px;background-color:rgba(128, 128, 128, 0.26);z-index: 17;  right: 27px; top: 5px;" id="span_loginpsw"></span>
                  <!---Alredy exists  ! -->
                  <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                </div>
                <div class="row">
                  <div class="col-xs-12">
                    <div id="error-login">
                    
                    </div>
                  </div>
                  <div class="col-xs-12 d-flex justify-content-center w-100">
                    <button type="button" class="btn bg-primary text-light" id="ulogujSe">Sign In</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
  <!--/ Modal box-->