    <!-- Page Content -->
    <div class="container">        
        <!-- About Section -->
        <div class="about-main">
            <div class="row">
               <div class="col-lg-6">
                  <h2>Welcome to UAP</h2>
                  <p>What started as a dream in 2011 to give back to the country of my birth has grown into a international movement. Since then —together— we have delivered 200 tons of aid worth $7 million to families and communities in need. We became the first humanitarian organization from the region to be granted Special Consultative Status with the United Nations and our 500+ members across 30 countries oversee a network of 1.8 million newsletter subscribers and social media followers.

But who gives a shit about numbers? They can’t measure the feeling that comes with recognizing that we have the ability and resources necessary to ensure that those in need are never turned away. The journey here has been perilous, but visionary movements use purpose as a fountain for resilience. We only get one chance on this Earth, and those of us fortunate enough to be able to help, have the obligation to do so as these gestures of kindness are ultimately the legacy we will leave behind.</p>
				  
               </div>
               <div class="col-lg-6">
                  <img class="img-fluid rounded w-100" src="assets/images/299723-P7FMOD-652.jpg" alt="images" />
               </div>
            </div>
            <!-- /.row -->
        </div>
	</div>	
	<?php require_once "models/gallery.php";?>
		
	<div class="container">
        <!-- Portfolio Section -->
        <div class="portfolio-main">
            <h2>Our Portfolio</h2>
            <div id="projects" class="projects-main row">
			<?php  foreach($slike as $item):   ?> 
               <div class="col-lg-4 col-sm-6 pro-item portfolio-item financial">
                  <div class="card h-100">
                     <div class="card-img">
                        <a href="assets/images/<?=$item->href?>" data-fancybox="images">
                           <img class="card-img-top" src="assets/images/<?=$item->href?>" alt="<?=$item->alt?>" />
                           <div class="overlay"><i class="fas fa-arrows-alt"></i></div>
                        </a>
                     </div>
                     <div class="card-body">
                        <h4 class="card-title">
                           <a href="#"><?=$item->alt?></a>
                        </h4>
                     </div>
                  </div>
               </div>
               <?php endforeach;?>
         
            <!-- /.row -->
        </div>
    </div>