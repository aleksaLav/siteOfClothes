 <!-- pocetak registracije -->
    
 <div id="registration" class="container-fluid pt-2 pb-5" >
        <!-- <form onSubmit="proveraRegistracije()" action="models/registracija.php" method="post">  -->
            <h2 class="container-fluid d-flex justify-content-center">REGISTRATION</h2>
            <div class="container-fluid d-flex justify-content-center align-items-center flex-wrap mt-4 mb-4">
            <div id="greskeRegistracija" class="text-danger">
            <?php
				// if(isset($_SESSION['greskeRegistr'])){
				// 	foreach( $_SESSION['greskeRegistr'] as $i ){
				// 		echo $i."<br>";
				// 	}
				// 	unset($_SESSION['greskeRegistr']);
				// }
			?>
            </div>

            </div>
            <div class="container-fluid d-flex justify-content-center align-items-center flex-wrap">
                <div id="podaciZaRegKorisnika" class="col-xl-7 col-lg-7 col-md-10 col-ms-10 border border-secondary rounded p-3">
                    <div class="styled-input agile-styled-input-top">
                        <span id="errorRegisterName" class="text-danger"></span>
                        <input type="text" id='imeRegister' name="name" placeholder="Your name">
                        <label>The name must start with an uppercase letter, and the rest lowercase, the user can have multiple names (max 2), the name must contain min 2 , max 14 characters.</label>
                     </div>
                     <div class="styled-input agile-styled-input-top">
                        <span id="errorRegisterSurname" class="text-danger"></span>
                        <input type="text" id='PrezimeRegister' name="surname" placeholder="Your surname">
                        <label>The surname must start with an uppercase letter, and the rest lowercase, the user can have multiple surname (max 2), the name must contain min 2 , max 14 characters.</label>
                     </div>
                    <div class="styled-input">
                        <span id="errorRegisterEmail" class="text-danger"></span>
                        <input type="email" id='emailRegister' name="email" placeholder="Enter your email address"> 
                        <label>Email address must contain an @ tag, example of email format: example -@gmail.com</label>
                    </div>
                    <div class="styled-input agile-styled-input-top">
                        <span id="errorRegisterUserName" class="text-danger"></span>
                        <input type="text" id='korisnickoIme' name="userName" placeholder="Your  username">
                        <label>The username must contain a minimum of 3 and a maximum of 15 characters.The username can be anything, e.g. Your nickname: riki_12</label>
                     </div>
                    <div class="styled-input">
                        <span class="errorRegisterPassword text-danger"></span>
                        <input type="password" id='lozinka' name="password" placeholder="Your password">
                        <label>The password must contain a minimum of 4 and a maximum of 15 characters. It is recommended that the password includes numbers and special characters - e.g. riki1237 / 12 * @</label> 
                    </div>
                    <div class="styled-input">
                        <span class="errorRegisterPassword text-danger"></span>
                        <input type="password" id='lozinkaPotvrda' name="againPass" placeholder="Confirm your password"> 
                        <label>Passwords must match!</label> 
                    </div>
                     <div > 
                        <div class="click">
                            <input id='sendMessageButton' class="btn border border-dark"  name="sendMessageButton" type="button" value="REGISTER" > </div>
                    </div>
                </div>
            </div>
        <!-- </form> -->
    </div>
    <!-- kraj registracije -->