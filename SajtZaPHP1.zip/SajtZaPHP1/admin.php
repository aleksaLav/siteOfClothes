<?php
session_start();
if(isset($_SESSION['korisnik']) && $_SESSION['korisnik']->naziv=="korisnik" || !isset($_SESSION['korisnik'])){
    header("Location: index.php");
}
?>
<?php require "views/head.php";?>
<?php require "views/navAdmin.php";?>
<?php require "views/navigacijaAdmin.php";?>
<?php 
if(isset($_GET['page'])){
    $page = $_GET['page'];
    switch($page){
        case "dodajProizvod":
        require   "views/formaInsert.php";
        break;
         case "azurirajPostojeci":
        require  "views/formaUpdate.php";
        break;
        case "anketa":
        require  "views/anketaAdmin.php";
        break;
        case "narudzbine":
        require  "views/narudzbine.php";
        break;
        case "korisnici":
        require  "views/korisnikTabela.php";
        break;
        case "kontakt":
        require  "views/kontaktAdmin.php";
        break;
    }
}
?>
<?php require "views/scriptAdmin.php";?>