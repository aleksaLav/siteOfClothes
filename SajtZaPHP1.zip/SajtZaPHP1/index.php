<?php
ob_start();
   session_start();

if(isset($_SESSION['korisnik']) && $_SESSION['korisnik']->naziv=="admin"){
    header("Location: admin.php");
}

?>

<?php require "views/head.php";?>
<?php require "views/nav.php";?>
<?php require "views/header.php";?>
 <?php 
 if(isset($_SESSION['korisnik']) && $_SESSION['korisnik']->naziv!="admin"){
    require "views/anketa.php";
}
?> 
<?php 
if(isset($_GET['page'])){
    $page = $_GET['page'];
    switch($page){
        case "pocetna":
        require "views/pocetna.php";
        break;
         case "registrujse":
        require  "views/register.php";
        break;
        case "ulogujse":
        require  "views/login.php";
        break;
    }
}else{
    header("Location: index.php?page=pocetna&stranica=1");

}
?>
<?php require "views/contact.php";?>
<?php require "views/footer.php";?>
<?php require "views/script.php";

?>