$("#FormaUpdate").hide();
 $(document).ready(function(){
    $.ajax({
        url:"logic/kategorije.php",
        dataType:"json",
        success:function(data){
          console.log(data);
          ispisiKategorijeKodFormeUpdate(data);
        
        }
      })
      $(".pokupiIdUpdate").on("click",prikaziParemetreProizvodaUFormi);
      $("#dodaj").on("click",slanjeParametaraZaInsertProizvoda);
 })

 
 ////pocetak ipisa kategorije za formu update
function  ispisiKategorijeKodFormeUpdate(kategorije){
    let ispis = ``;
for (let k of kategorije) {
ispis+=`<option value="${k.idKategorija}">${k.naziv}</option>`;
}
$("#kategorijeProiz").append(ispis);
$("#katProizInsert").append(ispis);
}
////kraj ipisa kategorije za formu update

/////////////////

function prikaziParemetreProizvodaUFormi(e){
    e.preventDefault();
    $("#FormaUpdate").show();
    //let idKateg = $(this).data('idkategor');
    let idProizvod = $(this).data('idproizvod');
    $.ajax({
        url:"logic/upisProizUFormu.php",
        data: {
          //idKat:idKateg,
          idproiz:idProizvod,
          send:true
        },
        method:"post",
        dataType:"json",
        success:function(data,status,jqXHR){
            
          $("#nazivProizvoda").val(data.naziv);
          $("#novaCena").val(data.novaCena);
          $("#staraCena").val(data.staraCena);
          $("#kategorijeProiz").val(data.idKat);
          $("#kolicina").val(data.kolicina);
          $("#idProizvod").val(data.idProizvod);
          console.log(jqXHR.status);
          console.log(data);
        },
        error: function(xhr,status,error){
      
          console.log(xhr.responseText);
          var poruka = "Error";
      
          switch(xhr.status){
              case 404:
                  poruka = "Strana nije pronadjena";
                  break;
              case 409:
                  poruka = "";
                  break;
              case 422:
                  poruka = "";
                  break;
              case 500:
                  poruka = "";
                  break;
              
          }
          alert(poruka);
      
      }
      });


        // Make sure this.hash has a value before overriding default behavior
        if (this.hash !== "") {
          // Prevent default anchor click behavior
          event.preventDefault();
    
          // Store hash
          var hash = this.hash;
    
          // Using jQuery's animate() method to add smooth page scroll
          // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area
          $('html, body').animate({
            scrollTop: $(hash).offset().top
          }, 800, function(){
       
            // Add hash (#) to URL when done scrolling (default click behavior)
            window.location.hash = hash;
          });
        } // End if
}
function slanjeParametaraZaInsertProizvoda(){
     var naziv= $("#nazivProizInsert").val();
     var novaCena= $("#novaCenaInsert").val();
      var staraCena= $("#staraCenaInsert").val();
      var katProiz= $("#katProizInsert").val();
      var kolicina= $("#kolicinaInsert").val();
      var src= $("#srcInsert").val();
      var alt= $("#altInsert").val();
    //   alert(naziv)
    $.ajax({
        url:"logic/insert.php",
        data: {
            naziv:naziv,
            novaCena:novaCena,
            staraCena:staraCena,
            katProiz:katProiz,
            kolicina:kolicina,
            src:src,
            alt:alt,
            send:true
        },
        method:"post",
        dataType:"json",
        success:function(data,status,jqXHR){
            alert("Uspešno ste dodali proizvod u bazu!!!");
            location.reload();
        },
        error: function(xhr,status,error){
      
          console.log(xhr.responseText);
          var poruka = "Error";
      
          switch(xhr.status){
              case 404:
                  poruka = "Strana nije pronadjena";
                  break;
              case 409:
                  poruka = "409";
                  break;
              case 422:
                  poruka = "333";
                  break;
              case 500:
                  poruka = "444";
                  break;
              
          }
          alert(poruka);
      
      }
      });
}

$(".pokupiIdDelete").on("click",function(e){
  e.preventDefault();
  let idProizvod = $(this).data('id');

  $.ajax({
    url:"logic/delete.php",
    data: {
      id:idProizvod
    },
    method:"post",
    dataType:"json",
    success:function(data,status,jqXHR){
      console.log(jqXHR.status);
      console.log(data);
      alert("Uspešno ste obrisali!");
      location.reload();
    },
    error: function(xhr,status,error){
  
      console.log(xhr.responseText);
  
      switch(xhr.status){
          case 404:
              alert("Stranica nije pronađena.");
              break;
          case 500:
              alert("Nemoguca naredba!")
              break;
          default:
            alert("Error: "+xhr.status+'-'+error); 
            break;       
          
      }

  
  }
  });

});