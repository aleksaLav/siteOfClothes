$(document).ready(function () {
    $("#btnRegistruj").on("click", registruj);
    $("#glasaj").on("click",odgovorAnketa);
    $("#posalji").on("click",posaljiKontaktPodatke)
    function registruj() {
        var ime = $("#imeRegister").val().trim();
        var prez = $("#PrezimeRegister").val().trim();
        var email = $("#emailRegister").val().trim();
        var korisnickoIme = $("#korisnickoIme").val().trim();
        var lozinka = $("#lozinka").val().trim();
        var opetLozinka = $("#lozinkaPotvrda").val().trim();
        $.ajax({
            url: "logic/registruj.php",
            method: "POST",
            data: {
                Ime: ime,
                Prezime: prez,
                Email: email,
                UserName: korisnickoIme,
                Password: lozinka,
                OpetPassword: opetLozinka,
                send: true
            },
            dataType: "json",
            success: function (data) {
                alert("Uspešno ste se registrovali!");
                location.reload();
            },
            error: function (xhr, error, status) {
                console.log(xhr.responseText);
                console.log(xhr.responseJson);
                console.log(error);
                console.log(status);

                let code = xhr.status;
                let poruka = "Došlo je do greske!";
                switch (code) {
                    case 404:
                        poruka = "Stranica nije pronađena!";  
                        break;
                    case 409:
                        poruka = "Ovaj email ili korisničko ime već postoji!";
                        break;
                    case 422:
                        poruka = "Došlo je do greške prilikom registrovanja! Proverite podatke!";
                        break;
                    case 500:
                        poruka = "Serverska greška, probajte ponovo!";
                        break;

                }
                alert(poruka);
                var jsonGreske = xhr.responseJSON;
                console.log(jsonGreske);
                let ispis = ``;
                for (let item of jsonGreske) {
                    ispis += "<b>"+item + "</b><br/>";
                }
                 jsonGreske=[]
                let pozicija= document.getElementById("greskeRegistracija").offsetTop;
                  document.body.scrollTop = pozicija/2;
                  document.documentElement.scrollTop = pozicija /2;
                  $("#greskeRegistracija").html(ispis);
            }
        })
    }


    //////////////////////////
    //////////////////////////
    //odavde je stari js
    $.ajax({
        url: "logic/dohvatanjeProizvoda.php",
        method: "get",
        dataType: "json",
        success: function (data) {
           // console.log(data);
            ispisProizvoda(data)

            document.querySelector("#search").addEventListener("input", function () {
                pretragaProizvoda(data)
            });
            $("#sortiraj").click(function () {
                sortiranje(data)
            })
            // $(".korpa").click(DODAJuKORPU);
        },
        error: function (xhr, error, status) {
            console.log(xhr.responseText)
            console.log(status)
            console.log(error)
        }
    })
    // ispisKategorija()
    document.getElementById("kategorija").addEventListener("change", function () {
        filtriranjePoKategoriji(this.value)
    })
   // $("#prioritet a").click(prioritet);
    range()
    $("[type=range]").change(range);
    upisiUkorpu()

})

function ispisProizvoda(data) {
    let ispis = '';
    let brojStrana=Math.ceil(Number(data.brojProizvoda)/5);
    //console.log(brojStrana)
    let ispisLinkova='';
    for(let i=1; i<=brojStrana; i++){
        if(i==brojStrana){
            ispisLinkova+=`<a href="index.php?page=pocetna&stranica=${i}">${i}</a>`
        }else
        {
        ispisLinkova+=`<a href="index.php?page=pocetna&stranica=${i}">${i}</a> / `}
    }
    
    //console.log(ispisLinkova)

    function stanje(x) {
        if (x > 0) {
            return "<span class='zelena  p-2'>na stanju</span>"
        }
        else {
            return "<span class='crvena  p-2 textcenter'>trenutno nije na stanju</span>"
        }
    }
    function ObavestenjeOStanje(x) {
        if (x > 0) {
            return true;
        }
        else {
            return false;
        }
    }
    function postojiCena(stara, nova) {
        if (stara == nova) {
            return "";
        }
        else if (stara == null) {
            return "";
        }
        else return stara + " rsd"
    }
    data.proizvodi.forEach(element => {

        ispis += `
            <div class="col-xl-2 col-lg-3 col-md-5 col-sm-11 text-break border mb-1 m-2">
            <img src="${element.src}" class="w-100" />
            <p class="pt-2">${element.naziv}</p>
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 pt-2 d-flex justifycontent-centar">
            ${stanje(element.kolicina)}
            </div>
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 pt-2 pb-3 d-flex justifycontent-around flex-wrap">
            <span class="novaCena"><b>${element.novaCena} rsd</b></span><del>
            ${postojiCena(element.staraCena, element.novaCena)}
            </del>
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 pt-2 pb-3">
            <button id="korpa" class="korpa btn border border-dark" data-id="${element.idProizvod}" data-cena="${element.novaCena}" data-stanje="${ObavestenjeOStanje(element.kolicina)}">dodaj u korpu</button>
            </div>
            </div>
            </div>
            `

    });

    document.getElementById("proizvodi").innerHTML = ispis;
    $("#linkoviProiz").html(ispisLinkova);
    $(".korpa").click(DODAJuKORPU);
}
///filtriranje
function ispisProizvodaFilter(data) {
    let ispis = '';
    //console.log(data)
    // let brojStrana=Math.ceil(Number(data.brojProizvoda)/5);
    // console.log(brojStrana)
    // let ispisLinkova='';
    // for(let i=1; i<=brojStrana; i++){
    //     if(i==brojStrana){
    //         ispisLinkova+=`<a href="index.php?page=pocetna&stranica=${i}">${i}</a>`
    //     }else
    //     {
    //     ispisLinkova+=`<a href="index.php?page=pocetna&stranica=${i}">${i}</a> / `}
    // }
    
    // console.log(ispisLinkova)

    function stanje(x) {
        if (x > 0) {
            return "<span class='zelena  p-2'>na stanju</span>"
        }
        else {
            return "<span class='crvena  p-2 textcenter'>trenutno nije na stanju</span>"
        }
    }
    function ObavestenjeOStanje(x) {
        if (x > 0) {
            return true;
        }
        else {
            return false;
        }
    }
    function postojiCena(stara, nova) {
        if (stara == nova) {
            return "";
        }
        else if (stara == null) {
            return "";
        }
        else return stara + " rsd"
    }
    data.forEach(element => {

        ispis += `
            <div class="col-xl-2 col-lg-3 col-md-5 col-sm-11 text-break border mb-1 m-2">
            <img src="${element.src}" class="w-100" />
            <p class="pt-2">${element.naziv}</p>
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 pt-2 d-flex justifycontent-centar">
            ${stanje(element.kolicina)}
            </div>
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 pt-2 pb-3 d-flex justifycontent-around flex-wrap">
            <span class="novaCena"><b>${element.novaCena} rsd</b></span><del>
            ${postojiCena(element.staraCena, element.novaCena)}
            </del>
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 pt-2 pb-3">
            <button id="korpa" class="korpa btn border border-dark" data-id="${element.idProizvod}" data-cena="${element.novaCena}" data-stanje="${ObavestenjeOStanje(element.kolicina)}">dodaj u korpu</button>
            </div>
            </div>
            </div>
            `

    });

    document.getElementById("proizvodi").innerHTML = ispis;
    //$("#linkoviProiz").html(ispisLinkova);
    $(".korpa").click(DODAJuKORPU);
}

// function prioritet(e){
//  e.preventDefault();
//  let vrednostDataAttr=this.dataset.prioritet;
//  let niz=[];
//  $.ajax({
//  url:"data/proizvodi.json",
//  method:"get",
//  type:"json",
//  success:function(data){
//  niz=data.filter(x=> x.prioritet==vrednostDataAttr);
//  ispis(niz)
//  // $(".korpa").click(DODAJuKORPU);
//  },
//  error:function(xhr,error,status){
//  console.log(status);
//  }
//  })
// }


// function ispisKategorija(){
//  $.ajax({
//  url:"data/kategorije.json",
//  method:"get",
//  type:"json",
//  success:function(data){
//  let ispis='<select id="kategorija"><option value="0">KATEGORIJE (sve)</option>';
//  data.forEach(element => {
//  ispis+=`
//  <option value="${element.id}">
//  ${element.naziv}</option>
//  `
//  });
//  ispis+='</select>'
//  $("#sortFilter").html(ispis);
//  document.getElementById("kategorija").addEventListener("change",function(){
//  filtriranjePoKategoriji(this.value)
//  })
//  },
//  error:function(xhr,error,status){
//  console.log(status)
//  }
//  })
// }
function filtriranjePoKategoriji(vrednostSElect) {
    $.ajax({
        url: "logic/dohvatanjeProizvoda.php",
        method: "get",
        type: "json",
        success: function (data) {
            
          //   console.log(data.proizvodiFiltriranje)
            if (vrednostSElect != 0) {
                niz = data.proizvodiFiltriranje.filter(function (x) {
                    return x.idKat == vrednostSElect;
                });
            }
            ispisProizvodaFilter(niz)
            // $(".korpa").click(DODAJuKORPU);
        },
        error: function (xhr, error, status) {
            console.log(status)
        }
    })
}
function pretragaProizvoda(data) {
    let rezPretrage = document.querySelector("#search").value;
    let niz = data.proizvodiFiltriranje.filter(function (x) {
        if (x.nazivKat.toLowerCase().indexOf(rezPretrage.toLowerCase()) !== -1)
            return true;
        if (x.naziv.toLowerCase().indexOf(rezPretrage.toLowerCase()) !== -1)
            return true;
    })
    if (!niz.length) {
        document.getElementById("proizvodi").innerHTML = "<h1 class='w-100 text-center'>NEMA TAKVIH PROIZVODA!</h1><h5 class='w-100 text-center'>(probajte ponovo da upišete naziv proizvoda ili njenu kategoriju) </h5>"

    } else {
        niz.sort((a, b) => a.novaCena - b.novaCena);
        ispisProizvodaFilter(niz);
    }
}
function sortiranje(data) {
    let cenaOd = document.getElementById("range1").value;
    let cenaDo = document.getElementById("range2").value;
    cenaOd= parseFloat(cenaOd)
    cenaDo= parseFloat(cenaDo)
    let kategorija = $("#kategorija").val();
    let niz = []
    if (kategorija != 0) {
        niz = data.proizvodiFiltriranje.filter(function (x) {
            return x.idKat == kategorija;
        });
    } else {
        niz = data.proizvodiFiltriranje;
    }
    niz = niz.filter(function (x) {
        if (x.novaCena >= cenaOd && x.novaCena <= cenaDo)
            return true
    })

    if (!niz.length) {
        document.getElementById("proizvodi").innerHTML = "<h1 class='w-100 text-center'>NEMA TAKVIH PROIZVODA!</h1><h5 class='w-100 text-center'>(probajte ponovo da podesite cene i izaberete kategoriju) </h5>"

    } else {
        niz.sort((a, b) => a.novaCena - b.novaCena);
        ispisProizvodaFilter(niz);
    }
}
function range() {
    let vrednost1 = document.getElementById("range1").value;
    let vrednost2 = document.getElementById("range2").value;

    document.getElementById("OfValeuPrice").innerHTML = vrednost1;
    document.getElementById("toValuePrice").innerHTML = vrednost2;
}
// local storage
///////////////////////////////////////////////////////////
function upisiUkorpu() {
    var proizvodi = PROIZVODIuKORPI();
    if (proizvodi == null) {
        proizvodi = 1;
    }
    var brojPorudz = proizvodi.length;
    $("#brojPorudz").html(brojPorudz);
}
function PROIZVODIuKORPI() {
    return JSON.parse(localStorage.getItem("products"));
}
function DODAJuKORPU() {
    let id = $(this).data("id");
    let cena = $(this).data("cena");
    let naStanju = $(this).data("stanje");
    var proizvodi = PROIZVODIuKORPI();
    if (naStanju) {
        if (proizvodi) {

            if (DaLiVecPostojiUKorpi()) {
                let proizvodi = PROIZVODIuKORPI();
                for (let i of proizvodi) {
                    if (i.id == id) {
                        i.quantity++;
                        break;
                    }
                }
                localStorage.setItem("products", JSON.stringify(proizvodi))
            }
            else {
                let proizvodi = PROIZVODIuKORPI();
                proizvodi.push({
                    id: id,
                    quantity: 1,
                    price:Number(cena)
                });
                localStorage.setItem("products", JSON.stringify(proizvodi))
            }
        }
        else {
            let products = [];
            products[0] = {
                id: id,
                quantity: 1,
                price:Number(cena)
            };
            localStorage.setItem("products", JSON.stringify(products));
        }
    }
    else {
        alert("Proizvod trenutno nije na stanju!")
    }
    upisiUkorpu()

    function DaLiVecPostojiUKorpi() {
        return proizvodi.filter(p => p.id == id).length;
    }
}
function odgovorAnketa(){
   var idProizvod=$("#proizvodAnketa").val();
    $.ajax({
        url:"logic/upisAnketaOdgovor.php",
        data: {
          id:idProizvod,
          send:true
        },
        method:"post",
        dataType:"json",
        success:function(data,status,jqXHR){
          console.log(jqXHR.status);
          //console.log(data);
          alert("Uspešno ste glasali!");
         // location.reload();
        },
        error: function(xhr,status,error){
      
          console.log(xhr.responseText);
      
          switch(xhr.status){
              case 404:
                  alert("Stranica nije pronađena.");
                  break;
              case 500:
                  alert("Već ste glasali na ovu anketu!")
                  break;
              default:
                alert("Error: "+xhr.status+'-'+error); 
                break;        
          } 
      }
      });
}
function posaljiKontaktPodatke(){
    let imePrez=$("#ime").val();
    let email=$("#email").val();
    let telefon= $("#telefon").val();
    let poruka=$("#poruka").val();
    let cekirano=$("#poruka").val();
    $.ajax({
        url:"logic/kontaktForma.php",
        data: {
          imePrez:imePrez,
          email:email,
          telefon:telefon,
          poruka:poruka,
          cekirano:cekirano,
          send:true
        },
        method:"post",
        dataType:"json",
        success:function(data,status,jqXHR){
          console.log(jqXHR.status);
          //console.log(data);
         //alert("Uspešno ste glasali!");
         // location.reload();
        },
        error: function(xhr,status,error){
      
          console.log(xhr.responseText);
      
          switch(xhr.status){
              case 404:
                  alert("Stranica nije pronađena.");
                  break;
              case 500:
                  alert("greska st.koda 500!")
                  break;
              default:
                alert("Error: "+xhr.status+'-'+error); 
                break;        
          } 
      }
      });
}
// function skrolujDoKontakt(){
//   var pozicija=  $("#SlikaKontakte").offsetTop;
//     document.body.scrollTop = pozicija/2;
//    document.documentElement.scrollTop = pozicija /2;
// }