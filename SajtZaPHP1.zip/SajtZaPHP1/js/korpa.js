$(document).ready(function () {
    let products = JSON.parse(localStorage.getItem("products"));
    if (products == null) {
        products = 0;
    }
    let nizProizvodaULocalstorage = products.length;
    if (nizProizvodaULocalstorage) {
        prikaziProizvodeIzKorpe()
    }
    else {
        PrikazZaPraznuKorpu();
    }
    // $(".quantity").on("change", updateKolicinaIUkupnaCenaPoProizvodu)
    
});
function prikaziProizvodeIzKorpe() {
    let products = PROIZVODIuKORPI();
    $.ajax({
        url: "logic/DohvatanjeProizvodaKorpa.php",
        dataType: "json",
        success: function (data) {
            console.log(products)
            data = data.filter(p => {
                for (let prod of products) {
                    if (p.idProizvod == prod.id) {
                        p.quantity = prod.quantity;
                        return true;
                    }

                }
                return false;
            });
            ispisiTabelu(data)
        }
    });
}
function ispisiTabelu(products) {
    //header
    let ispis = `
 <table class="timetable_sub">
 <thead>
 <tr>

 <th>SLIKA</th>
<th>NAZIV PROIZVODA</th>
<th>CENA PO KOMADU</th>
 <th>KOLIČINA</th>
<th>UKUPNA CENA ZA OVAJ PROIZVOD</th>
 <th>IZBACI IZ KORPE</th>
 </tr>
 </thead>
 <tbody>`;
    //body
    products.forEach(p => {
        ispis +=
            `<tr>

 <td >
 <a href="single.html">
 <img src="${p.src}" style='height:100px' alt="${p.alt}" class="img
-responsive">
 </a>
 </td>
 <td >${p.naziv}</td>
 <td >$${p.novaCena}</td>
 <td >
 <input type="number" data-id="${p.idProizvod}" class="quantity" name="quantity" min="1" max="100" value="${p.quantity}">
 </td>
 <td id="cena">${cenaPoProizvodu(p)} rsd</td>
 <td >
 <div>
 <div><button type="submit" onclick='obrisiIzKorpe(${p.idProizvod})'>Obriši</button> </
div>
 </div>
 </td>
 </tr>`
    });
    //footer
    ispis += `<tr>
 <th colspan="4">UKUPNO IMATE DA PLATITE:</th>
 <th>${ukupnaCena()} din</th>
 <th><button class="p-2" id="naruci">NARUČI</ button></th>
 </tr> </tbody>
 </table>`;
    $("#content").html(ispis);
    $("#naruci").on("click",upisiPorudzbinuUBazu);
    $(".quantity").on("change", updateKolicinaIUkupnaCenaPoProizvodu)
    function ukupnaCena() {
        let ukupno = 0;
        for (let p of products) {
            ukupno += (p.novaCena * p.quantity);
        }
        return ukupno;
    }
    function cenaPoProizvodu(x) {
        let y;
        y = x.quantity * x.novaCena
        return y;
    }
}
function updateKolicinaIUkupnaCenaPoProizvodu() {
    //console.log($(this).val());
    let products = PROIZVODIuKORPI();
    let kolicina = Number($(this).val());
    let x = $(this).data("id");
    for (let prod in products) {
        if (products[prod].id == x) {
            products[prod].quantity = kolicina;
            break;
        }
    }
    localStorage.setItem("products", JSON.stringify(products))
    prikaziProizvodeIzKorpe()
}
function PrikazZaPraznuKorpu() {
    $("#content").html("<h1>TVOJA KORPA JE PRAZNA!</h1>")
}
function PROIZVODIuKORPI() {
    return JSON.parse(localStorage.getItem("products"));
}
function obrisiIzKorpe(id) {
    let products = PROIZVODIuKORPI();
    let filtrirano = products.filter(p => p.id != id);
    localStorage.setItem("products", JSON.stringify(filtrirano));
    prikaziProizvodeIzKorpe()
}
function upisiUlocalStorage(x) {
    let products = PROIZVODIuKORPI();
    let kolicina = this.value;
    console.log(kolicina)
    for (let prod in products) {
        if (products[prod].id == x) {
            products[prod].quantity;
            break;
        }
    }
    localStorage.setItem("products", JSON.stringify(products))
}
// function obavestenje() {
//     let products = PROIZVODIuKORPI();
//     products = null
//     localStorage.setItem("products", JSON.stringify(products))
//     PrikazZaPraznuKorpu()
//     alert("USPEŠNO STE NARUČILI!!!")
// }



function upisiPorudzbinuUBazu() {
    let proizvodiLS = JSON.parse(localStorage.getItem("products"));
    $.ajax({
        url: "logic/porudzbina1.php",
        data: {
            proizvodiLS: proizvodiLS,
            send: true
        },
        method: "post",
        dataType: "json",
        success: function (data, status, jqXHR) {
            console.log(data)
            let products = PROIZVODIuKORPI();
            products = null
            localStorage.setItem("products", JSON.stringify(products))
            PrikazZaPraznuKorpu()
            alert("USPEŠNO STE NARUČILI!!!")
            location.reload();
        },
        error: function (xhr, status, error) {

            console.log(xhr.responseText);
            console.log(status);
            console.log(error);
            var poruka = "Error";

            switch (xhr.status) {
                case 404:
                    poruka = "Strana nije pronadjena!!!";
                    break;
                case 409:
                    poruka = "ERROR 409";
                    break;
                case 422:
                    poruka = "ERROR 422";
                    break;
                case 500:
                    poruka = "NISTE ULOGOVANI!!! \n \n ULOGUJTE SE!!!";
                    break;

            }
            alert(poruka);

        }
    });
}