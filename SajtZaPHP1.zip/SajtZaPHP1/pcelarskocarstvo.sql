-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2020 at 08:30 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pcelarskocarstvo`
--

-- --------------------------------------------------------

--
-- Table structure for table `anketa`
--

CREATE TABLE `anketa` (
  `idAnketa` int(30) NOT NULL,
  `pitanje` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `aktivna` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cena`
--

CREATE TABLE `cena` (
  `idProizvod` int(255) NOT NULL,
  `staraCena` decimal(10,2) DEFAULT NULL,
  `novaCena` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cena`
--

INSERT INTO `cena` (`idProizvod`, `staraCena`, `novaCena`) VALUES
(1, NULL, '1250.00'),
(3, '250.00', '300.00'),
(4, NULL, '1000.00'),
(5, '1300.00', '1500.00'),
(6, '320.00', '300.00'),
(7, NULL, '1000.00'),
(8, '80.00', '100.00'),
(9, '1200.00', '1100.00'),
(10, '850.00', '900.00'),
(11, '920.00', '950.00'),
(12, NULL, '600.00'),
(23, '470.00', '500.00'),
(24, '800.00', '780.00'),
(25, '2000.00', '2300.00'),
(26, NULL, '12500.00'),
(31, '1700.00', '1800.00'),
(32, '1100.00', '1050.00'),
(35, '350.00', '300.00'),
(36, '160.00', '165.00'),
(38, '321.00', '12.00');

-- --------------------------------------------------------

--
-- Table structure for table `detaljiporudzbine`
--

CREATE TABLE `detaljiporudzbine` (
  `idDetalji` int(4) NOT NULL,
  `idProizvoda` int(50) NOT NULL,
  `kolicina` int(4) NOT NULL,
  `cena` decimal(6,2) NOT NULL,
  `idPorudzbine` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `izabranodgovora`
--

CREATE TABLE `izabranodgovora` (
  `idKorisnik` int(10) NOT NULL,
  `idProizvod` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kategorija`
--

CREATE TABLE `kategorija` (
  `idKategorija` int(10) NOT NULL,
  `naziv` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `kategorija`
--

INSERT INTO `kategorija` (`idKategorija`, `naziv`) VALUES
(1, 'OPREMA ZA RAD'),
(9, 'PČELINJI PROIZVODI'),
(11, 'RAZNO');

-- --------------------------------------------------------

--
-- Table structure for table `kontaktforma`
--

CREATE TABLE `kontaktforma` (
  `idKontakt` int(10) NOT NULL,
  `imePrezime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `telefon` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `poruka` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `korisnik`
--

CREATE TABLE `korisnik` (
  `idKorisnik` int(255) NOT NULL,
  `ime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `prezime` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `korisnickoIme` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `lozinka` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `idUloga` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `korisnik`
--

INSERT INTO `korisnik` (`idKorisnik`, `ime`, `prezime`, `korisnickoIme`, `email`, `lozinka`, `idUloga`) VALUES
(1, 'Aleksandar Stosic', 'Aleksandar Stosic', 'aca12', 'aca.sto92@gmail.com', 'ab71fa41ab7c8e34b447e9c4df5ab8ec', 1),
(2, 'Aleksa', 'Stosic', 'aki99', 'acass.sto92@gmail.com', 'f3071ec919ba79ea9d6fbe49c2c53a3d', 2);

-- --------------------------------------------------------

--
-- Table structure for table `meni`
--

CREATE TABLE `meni` (
  `idMeni` int(10) NOT NULL,
  `naziv` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `href` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `odgovor`
--

CREATE TABLE `odgovor` (
  `idKorisnik` int(10) NOT NULL,
  `idAnketa` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `porudzbina`
--

CREATE TABLE `porudzbina` (
  `idPorudzbina` int(4) NOT NULL,
  `datumNarucivanja` date NOT NULL DEFAULT current_timestamp(),
  `idKorisnik` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `porudzbina`
--

INSERT INTO `porudzbina` (`idPorudzbina`, `datumNarucivanja`, `idKorisnik`) VALUES
(14, '2020-04-02', 2),
(15, '2020-04-02', 2),
(16, '2020-04-02', 2),
(17, '2020-04-02', 2),
(18, '2020-04-02', 2),
(19, '2020-04-02', 2),
(20, '2020-04-02', 2),
(21, '2020-04-02', 2),
(22, '2020-04-02', 2),
(23, '2020-04-02', 2),
(24, '2020-04-02', 2),
(25, '2020-04-02', 2),
(26, '2020-04-02', 2),
(27, '2020-04-02', 2),
(28, '2020-04-02', 2),
(29, '2020-04-02', 2),
(30, '2020-04-02', 2),
(31, '2020-04-02', 2),
(32, '2020-04-02', 2),
(33, '2020-04-02', 2),
(34, '2020-04-02', 2),
(35, '2020-04-02', 2),
(36, '2020-04-02', 2),
(37, '2020-04-02', 2),
(38, '2020-04-02', 2),
(39, '2020-04-02', 2),
(40, '2020-04-02', 2),
(41, '2020-04-02', 2),
(42, '2020-04-02', 2),
(43, '2020-04-02', 2),
(44, '2020-04-02', 2),
(45, '2020-04-02', 2),
(46, '2020-04-02', 2),
(47, '2020-04-02', 2),
(48, '2020-04-02', 2),
(49, '2020-04-02', 2);

-- --------------------------------------------------------

--
-- Table structure for table `proizvod`
--

CREATE TABLE `proizvod` (
  `idProizvod` int(255) NOT NULL,
  `naziv` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `idKat` int(10) NOT NULL,
  `kolicina` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `proizvod`
--

INSERT INTO `proizvod` (`idProizvod`, `naziv`, `idKat`, `kolicina`) VALUES
(1, 'PĆELARSKI NOŽ(KLUČ)', 1, 25),
(3, 'PČELARSKA ČETKA', 1, 22),
(4, 'KLJEŠTA ZA RAMOVE', 1, 20),
(5, 'SPOLJAŠNI NOSAČ RAMOVA', 1, 15),
(6, 'Marker', 1, 30),
(7, 'DIMILICA', 1, 14),
(8, 'KAVEZ ZA MATICU', 1, 52),
(9, 'MED OD LIPE 1kg', 9, 0),
(10, 'BAGREMOV MED 1kg', 9, 24),
(11, 'LIVADSKI MED 1kg', 9, 13),
(12, 'PROPOLIS 100g', 9, 120),
(23, 'MATIČNA MLEČ 20ml', 9, 15),
(24, 'VOSAK 1kg', 9, 19),
(25, 'POLEN 1kg ', 9, 22),
(26, 'CENTRIFUGA ZA VRCANJE', 11, 1),
(31, 'PČELČARSKI ŠEŠIR SA BLUZOM', 11, 10),
(32, 'RUKAVICE', 11, 9),
(35, 'VILJUŠKA ZA OTVARANJE SAĆA', 11, 16),
(36, 'POGAČE ZA PREHRANJIVANJE', 11, 215),
(38, 'terrtgfgdasgsagsdf', 1, 12);

-- --------------------------------------------------------

--
-- Table structure for table `slika`
--

CREATE TABLE `slika` (
  `idProizvod` int(10) NOT NULL,
  `src` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alt` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `slika`
--

INSERT INTO `slika` (`idProizvod`, `src`, `alt`) VALUES
(1, 'images/pcelarskiKljuc.png', 'PĆELARSKI NOŽ(KLUČ)'),
(3, 'images/cetka.png', 'PČELARSKA ČETKA'),
(4, 'images/kljesta.png', 'KLJEŠTA ZA RAMOVE'),
(5, 'images/nosacRamova.png', 'SPOLJAŠNI NOSAČ RAMOVA'),
(6, 'images/marker.png', 'Marker'),
(7, 'images/dimilica.png', 'DIMILICA'),
(8, 'images/kavgezMatica.png', 'kavez za maticu'),
(9, 'images/medOdLipe.png', 'MED OD LIPE'),
(10, 'images/bagremov.png', 'BAGREMOV MED'),
(11, 'images/LivadskiMed.png', 'LIVADSKI MED'),
(12, 'images/propolis.png', 'PROPOLIS'),
(23, 'images/mlec.png', 'MATIČNA MLEČ'),
(24, 'images/vosak.png', 'VOSAK'),
(25, 'images/polen.png', 'POLEN'),
(26, 'images/centrifuga.png', 'CENTRIFUGA ZA VRCANJE'),
(31, 'images/sesirSaBluzom.png', 'PČELČARSKI ŠEŠIR SA BLUZOM'),
(32, 'images/rukavice.png', 'RUKAVICE'),
(35, 'images/jez.png', 'viljuška otvaranje saća'),
(36, 'images/pogaca.png', 'POGAČE ZA PREHRANJIVANJE'),
(38, 'gfdgasfdagsf', 'gsdfs');

-- --------------------------------------------------------

--
-- Table structure for table `uloga`
--

CREATE TABLE `uloga` (
  `idUloga` int(5) NOT NULL,
  `naziv` varchar(30) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `uloga`
--

INSERT INTO `uloga` (`idUloga`, `naziv`) VALUES
(1, 'admin'),
(2, 'korisnik');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `anketa`
--
ALTER TABLE `anketa`
  ADD PRIMARY KEY (`idAnketa`);

--
-- Indexes for table `cena`
--
ALTER TABLE `cena`
  ADD PRIMARY KEY (`idProizvod`);

--
-- Indexes for table `detaljiporudzbine`
--
ALTER TABLE `detaljiporudzbine`
  ADD KEY `idDetalji` (`idDetalji`),
  ADD KEY `idPorudzbine` (`idPorudzbine`),
  ADD KEY `idProizvoda` (`idProizvoda`);

--
-- Indexes for table `izabranodgovora`
--
ALTER TABLE `izabranodgovora`
  ADD PRIMARY KEY (`idKorisnik`),
  ADD KEY `idProizvod` (`idProizvod`);

--
-- Indexes for table `kategorija`
--
ALTER TABLE `kategorija`
  ADD PRIMARY KEY (`idKategorija`),
  ADD UNIQUE KEY `naziv` (`naziv`);

--
-- Indexes for table `kontaktforma`
--
ALTER TABLE `kontaktforma`
  ADD PRIMARY KEY (`idKontakt`);

--
-- Indexes for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD PRIMARY KEY (`idKorisnik`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idUloga` (`idUloga`);

--
-- Indexes for table `meni`
--
ALTER TABLE `meni`
  ADD PRIMARY KEY (`idMeni`),
  ADD UNIQUE KEY `naziv` (`naziv`);

--
-- Indexes for table `odgovor`
--
ALTER TABLE `odgovor`
  ADD PRIMARY KEY (`idKorisnik`),
  ADD KEY `idAnketa` (`idAnketa`);

--
-- Indexes for table `porudzbina`
--
ALTER TABLE `porudzbina`
  ADD PRIMARY KEY (`idPorudzbina`),
  ADD KEY `idKorisnik` (`idKorisnik`);

--
-- Indexes for table `proizvod`
--
ALTER TABLE `proizvod`
  ADD PRIMARY KEY (`idProizvod`),
  ADD UNIQUE KEY `naziv` (`naziv`),
  ADD KEY `idKat` (`idKat`);

--
-- Indexes for table `slika`
--
ALTER TABLE `slika`
  ADD PRIMARY KEY (`idProizvod`);

--
-- Indexes for table `uloga`
--
ALTER TABLE `uloga`
  ADD PRIMARY KEY (`idUloga`),
  ADD UNIQUE KEY `naziv` (`naziv`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `anketa`
--
ALTER TABLE `anketa`
  MODIFY `idAnketa` int(30) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `detaljiporudzbine`
--
ALTER TABLE `detaljiporudzbine`
  MODIFY `idDetalji` int(4) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kategorija`
--
ALTER TABLE `kategorija`
  MODIFY `idKategorija` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `kontaktforma`
--
ALTER TABLE `kontaktforma`
  MODIFY `idKontakt` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `korisnik`
--
ALTER TABLE `korisnik`
  MODIFY `idKorisnik` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `meni`
--
ALTER TABLE `meni`
  MODIFY `idMeni` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `porudzbina`
--
ALTER TABLE `porudzbina`
  MODIFY `idPorudzbina` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `proizvod`
--
ALTER TABLE `proizvod`
  MODIFY `idProizvod` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `uloga`
--
ALTER TABLE `uloga`
  MODIFY `idUloga` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cena`
--
ALTER TABLE `cena`
  ADD CONSTRAINT `cena_ibfk_1` FOREIGN KEY (`idProizvod`) REFERENCES `proizvod` (`idProizvod`) ON DELETE CASCADE;

--
-- Constraints for table `detaljiporudzbine`
--
ALTER TABLE `detaljiporudzbine`
  ADD CONSTRAINT `detaljiporudzbine_ibfk_1` FOREIGN KEY (`idPorudzbine`) REFERENCES `porudzbina` (`idPorudzbina`) ON DELETE CASCADE,
  ADD CONSTRAINT `detaljiporudzbine_ibfk_2` FOREIGN KEY (`idProizvoda`) REFERENCES `proizvod` (`idProizvod`);

--
-- Constraints for table `izabranodgovora`
--
ALTER TABLE `izabranodgovora`
  ADD CONSTRAINT `izabranodgovora_ibfk_1` FOREIGN KEY (`idKorisnik`) REFERENCES `korisnik` (`idKorisnik`) ON DELETE CASCADE;

--
-- Constraints for table `korisnik`
--
ALTER TABLE `korisnik`
  ADD CONSTRAINT `korisnik_ibfk_1` FOREIGN KEY (`idUloga`) REFERENCES `uloga` (`idUloga`);

--
-- Constraints for table `odgovor`
--
ALTER TABLE `odgovor`
  ADD CONSTRAINT `odgovor_ibfk_1` FOREIGN KEY (`idKorisnik`) REFERENCES `izabranodgovora` (`idKorisnik`) ON DELETE CASCADE,
  ADD CONSTRAINT `odgovor_ibfk_2` FOREIGN KEY (`idAnketa`) REFERENCES `anketa` (`idAnketa`) ON DELETE CASCADE;

--
-- Constraints for table `porudzbina`
--
ALTER TABLE `porudzbina`
  ADD CONSTRAINT `porudzbina_ibfk_1` FOREIGN KEY (`idKorisnik`) REFERENCES `korisnik` (`idKorisnik`) ON DELETE CASCADE;

--
-- Constraints for table `proizvod`
--
ALTER TABLE `proizvod`
  ADD CONSTRAINT `proizvod_ibfk_1` FOREIGN KEY (`idKat`) REFERENCES `kategorija` (`idKategorija`);

--
-- Constraints for table `slika`
--
ALTER TABLE `slika`
  ADD CONSTRAINT `slika_ibfk_1` FOREIGN KEY (`idProizvod`) REFERENCES `proizvod` (`idProizvod`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
