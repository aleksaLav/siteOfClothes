<div class="container-fluid d-flex justify-content-center">
<table class="table table-stripped table-bordered table-hover">
            <thead>
                <tr>
                    <th>ime</th>               
                    <th>prezime</th>
                    <th>naziv proizvoda</th>   
                    <th>količina</th>            
                    <th>datum narucivanja</th>
                    <th>cena</th>   
                </tr>
            </thead>
            <?php

       require_once "logic/narudzbinaAdmin.php";

                        foreach($porudzbina as $p):
                    ?>
            <tbody>
                <tr>
                    <td class="align-middle"><?= $p->ime?></td>
                    <td class="align-middle"><?= $p->prezime?></td>
                    <td class="align-middle"><?= $p->naziv?></td>
                    <td class="align-middle"><?= $p->kolicina?></td>
                    <td class="align-middle"><?= $p->datum?></td>
                    <td class="align-middle"><?= $p->cena?></td>
                </tr>
            </tbody>
            <?php endforeach;?>
        </table>
</div>
