<h1 class="nevidnjliv">str Pčelarsko carstvo,pcelarska radnja , pčelarska oprema, pčelarski proizvodi,str Pčelarsko carstvo,pcelarska radnja , pčelarska oprema, pčelarski proizvodi,str Pčelarsko carstvo,pcelarska radnja , pčelarska oprema, pčelarski proizvodi,str Pčelarsko carstvo,pcelarska radnja , pčelarska oprema, pčelarski proizvodi</h1>
    <!-- pocetak futer -->
    <div class="container-fluid d-flex justify-content-center futer">
    <div class="row col-lg-12 d-flex justify-content-around flex-wrap flex-row align-items-center ">

       <div class="col-xl-4 col-lg-4 col-md-6 col-ms-12  d-flex justify-content-center pb-3 pt-3">
            <button type="button" class="btn m-auto" data-toggle="modal" data-target="#exampleModalLong"> O MENI </button>
            <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Aleksa Stošić, 108/18</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                        </div>
                        <div class="modal-body"> <img src="images/autor.png" class="d-block m-auto w-100" alt="Aleksa-Stošić">
                            <p class="mt-4 autorP">Studiram u visokoj ICT školi već godinu dana, imam nekoliko projekata iza sebe, stalno se usavršavam i upoznajem sa novinama iz IT-sveta.</p>
                            <p class="mt-2 autorP">Ovde mozete pogledati moj <a href="https://aleksalav.github.io/portfolio-Web-developer-Aleksa-Stosic/" target="_blank">CV </a>.</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary text-dark" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
    </div>      
            <div class="col-xl-4 col-lg-4 col-md-6 col-ms-12 d-flex justify-content-center pb-3 pt-3">
                 <p class="">Copyright &COPY; 2020</p>
            </div>
            
            <div class="col-xl-4 col-lg-4 col-md-6 col-ms-12 d-flex justify-content-around pb-3 pt-3">
                    <ul class="col-xl-12 col-lg-12 col-md-12 col-ms-12 d-flex flex-row justify-content-around ">
                        <li><a href="https://www.facebook.com" target="_blank"><i class="fa fa-facebook-official mr-2 text-light"></i></a></li>
                        <li><a href="http://www.twitter.com" target="_blank"><i class="fa fa-twitter mr-2 text-light"></i></a></li>
                        <li><a href="http://www.google.com" target="_blank"><i class="fa fa-google-plus mr-2 text-light"></i></a></li>
                        <li><a href="http://www.pinterest.com" target="_blank"><i class="fa fa-pinterest mr-2 text-light"></i></a></li>
                        <li><a href="sitemap.xml" target="_blank"><i class="fa fa-linkedin text-light"></i></a></li>
                    </ul>
            </div>
        
    </div>
</div>
    <!-- kraj futer -->