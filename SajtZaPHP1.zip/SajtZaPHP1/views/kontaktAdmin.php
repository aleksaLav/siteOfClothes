<div class="container-fluid d-flex justify-content-center">
<table class="table table-stripped table-bordered table-hover">
            <thead>
                <tr>
                    <th>ime i prezime</th>               
                    <th>email</th>
                    <th>telefon</th>   
                    <th>poruka</th>            
                </tr>
            </thead>
            <?php

       require_once "logic/konekcija.php";
       $pripremaKontakt=$konekcija->query("SELECT * from kontaktforma")->fetchAll();

                        foreach($pripremaKontakt as $p):
                    ?>
            <tbody>
                <tr>
                    <td class="align-middle"><?= $p->imePrezime?></td>
                    <td class="align-middle"><?= $p->email?></td>
                    <td class="align-middle"><?= $p->telefon ?></td>
                    <td class="align-middle"><?= $p->poruka?></td>
                </tr>
            </tbody>
            <?php endforeach;?>
        </table>
</div>
