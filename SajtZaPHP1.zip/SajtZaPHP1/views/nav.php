<?php require_once "logic/meni.php";?>
<body>
      <!-- pocetak navigacije -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
        <a class="navbar-brand" href="index.php?page=pocetna">STR "Pčelarsko carstvo"</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse " id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
          <?php 
          if(!(isset($_SESSION['korisnik']) && $_SESSION['korisnik']->naziv == "korisnik")):
          foreach($izvrsi as $i):
          ?>
              <li class="nav-item">
                <a class="nav-link" href="<?= $i->href?>"><?= $i->naziv?></a>
              </li>
              <?php 
          endforeach;
          elseif((isset($_SESSION['korisnik']) && $_SESSION['korisnik']->naziv == "korisnik")):
            foreach($izvrsi as $i):
              if($i->naziv != "ULOGUJTE SE" && $i->naziv!="REGISTRUJ SE"):
              ?>
                  <li class="nav-item">
                    <a class="nav-link" href="<?= $i->href?>"><?= $i->naziv?></a>
                  </li>
                  <?php 
                   endif;
              endforeach;
           
          ?> 
              <li class="nav-item">
                    <a class="nav-link" href="logic/logout.php">IZLOGUJTE SE</a>
              </li>
          </ul>
            <?php endif;?>
        </div>
      </nav>
    <!-- kraj navigacije -->