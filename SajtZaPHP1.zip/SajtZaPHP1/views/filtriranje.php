<!-- pocetak filtriranje -->
<div class="container-fluid pb-3 pt-3 d-flex justify-content-center flex-wrap">
        <div class="col-xl-7 col-lg-7 col-md-12 col-sm-12 d-flex justify-content-around align-items-center flex-wrap border-right" >
            <div id="sortFilter" class="col-xl-2 col-lg-3 col-md-6 col-sm-12 d-flex justify-content-center"></div>
            <select name="" id="kategorija">
            <option value="0">KATEGORIJE (SVE)</option>
                <?php
                require "logic/konekcija.php";
               $KATEGORIJA= $konekcija->query("SELECT * from kategorija")->fetchAll();
                
                foreach ($KATEGORIJA as $kateg) :
                ?>
                <option value="<?= $kateg->idKategorija?>"><?=$kateg->naziv?></option>
<?php endforeach;?>
            </select> 
            
             
            <div class="col-xl-2 col-lg-3 col-md-12 col-sm-12 d-flex justify-content-center flex-wrap">
              OD CENE &nbsp;
              <span id="OfValeuPrice"></span>
              <input type="range"  min="0" max="20000" id="range1"> 
            </div>
            <div class="col-xl-2 col-lg-3 col-md-12 col-sm-12 d-flex justify-content-center flex-wrap">
              DO CENE &nbsp;
              <span id="toValuePrice"></span>
              <input type="range"  min="0" max="20000" id="range2"> 
            </div>
            <!-- <input type="text" id="phone" name="phone" placeholder="filter po datumu" class="bg-dark"> -->
            <DIV>
              <button id="sortiraj" class="btn border border-dark">prikazi</button>
            </DIV>

        </div>
        <div class="col-xl-2 col-lg-3 col-md-6 col-sm-12 d-flex justify-content-center">
          <form class="form-inline my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="search" placeholder="Pronađi proizvode..." aria-label="Search" id="search">
            
          </form>
        </div>
        <div class="col-xl-1 col-lg-2 col-md-6 col-sm-12 d-flex justify-content-center align-items-center">
        <a href="korpa.php">  <i class="material-icons">add_shopping_cart</i> = <span id="brojPorudz">0</span></a>
        </div>
      </div>
      <!-- kraj filtriranje -->