
    <!-- KONTAKT PODACI  -->
    <div class="container-fluid d-flex futer pt-3 pb-3 justify-content-center align-items-center flex-wrap">
      <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 d-flex flex-row align-items-center justify-content-center">
        <i class="large material-icons text-white">location_on</i><p class="text-wrap">Alekse Vojisavljevića 108/18,11000 BEOGRAD, radnim danima OD 6 DO 20h</p>
      </div>
      <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 d-flex flex-row justify-content-center">
        <i class="large material-icons text-white">local_phone</i> <p class="text-wrap">+381555445558</p>
      </div>
      <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 d-flex flex-row justify-content-center">
        <i class="large material-icons text-white">email</i><p>Pcelarsko-carstvo@gmail.com</p>
      </div>
  </div>
    <!-- KRAJ KONTAKT PODACI  -->


    <!-- pocetak forma -->
    <div id="SlikaKontakt" class="container-fluid 
    " >
        <form  >
            <h2 class="container-fluid d-flex justify-content-center">KONTAKT FORMA</h2>
            <div class="container-fluid d-flex justify-content-center align-items-center flex-wrap">
                <div id="textPitanja" class="col-xl-5 col-lg-5 col-md-10 col-ms-10">
                    <div class="styled-input agile-styled-input-top">
                        <label>Vaše ime i prezime:</label><span id="greskaImePrezime">*</span>
                        <input type="text" id='ime' name="Name" placeholder="Petar Perović Perić"> </div>
                    <div class="styled-input">
                        <label>Unesite vaš email:</label><span id="greskaEmail">*</span>
                        <input type="email" id='email' name="Email" placeholder="petar.peric123@gmail.com"> </div>
                    <div class="styled-input">
                        <label>Unesite vaš broj:</label><span id="greskaBroj">*</span>
                        <input type="text" id='telefon' name="phone" placeholder="06(y)/+3816(y)-xxx-xxx(y)">
                     </div>
                </div>
                <div id="LicniPodaci" class="col-xl-5 col-lg-5 col-md-10 col-ms-10">
                    
                    <div class="styled-input"><span id="greskaPoruke">*</span>
                        <textarea name="Message" id='poruka' placeholder="poruka..."></textarea>
                    </div>
                    <div class="styled-input">
                        <input type="checkbox" id='saglasnost' name="cekirano" value="" requireds>
                        <label>Da li ste saglasni sa prethodno navedenim podacima?</label>
                    </div>
                    <div> <span id="agree">*</span>
                        <div class="click">
                            <input id='posalji'name="posalji" class="btn" type="button" value="POŠALJI" > </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- kraj forme -->