<br><br><br>
<div class="container-fluid d-flex flex-wrap pb-5">
<a href="admin.php?page=dodajProizvod" class="w-100 d-flex justify-content-center">Dodaj proizvod</a>
<a href="admin.php?page=azurirajPostojeci" class="w-100 d-flex justify-content-center">Azuriraj/Obriši</a>
<a href="admin.php?page=anketa" class="w-100 d-flex justify-content-center">Anketa</a>
<a href="admin.php?page=narudzbine" class="w-100 d-flex justify-content-center">Narudžbine</a>
<a href="admin.php?page=korisnici" class="w-100 d-flex justify-content-center">Korisnici</a>
<a href="admin.php?page=kontakt" class="w-100 d-flex justify-content-center">Kontakt</a>
</div>