<div class="container-fluid d-flex justify-content-center">
<table class="table table-stripped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Naziv</th>               
                    <th>broj glasanja</th>
                </tr>
            </thead>
            <?php

       require_once "logic/anketaTabela.php";

                        foreach($proizvodi as $p):
                    ?>
            <tbody>
                <tr>
                    <td class="align-middle"><?= $p->naziv?></td>
                    <td class="align-middle"><?= $p->broj?></td>
                </tr>
            </tbody>
            <?php endforeach;?>
        </table>
</div>
