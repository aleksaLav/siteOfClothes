

<!-- Button trigger modal -->
<button type="button" class="btn btn-primary" id="btnAnketa"  data-toggle="modal" data-target="#exampleModalLongAnketa">
  ANKETA
</button>

<!-- Modal -->
<div class="modal fade" id="exampleModalLongAnketa" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">ANKETNO PITANJE</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <?php require "logic/konekcija.php"; ?>

    <label>Koji Vam je najomiljeniji proizvod?</label>
    <select id="proizvodAnketa">
    <?php 
    $proizvodi= $konekcija->query("SELECT * from proizvod")->fetchAll();
    foreach ($proizvodi as  $p):
    ?>
    <option value="<?= $p->idProizvod?>"><?= $p->naziv?></option>
    <?php 
    endforeach;
    ?>
    </select>

      </div>
      <div class="modal-footer">
        <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
        <button type="button" class="btn btn-primary" id="glasaj">GLASAJ</button>
      </div>
    </div>
  </div>
</div>
