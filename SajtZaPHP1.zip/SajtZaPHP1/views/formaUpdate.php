<div class="container-fluid d-flex justify-content-center">
<table class="table table-stripped table-bordered table-hover">
            <thead>
                <tr>
                    <th>Naziv</th>
                    <th>Nova cena</th>
                    <th>Stra cena</th>  
                    <!-- <th>ID kategorije</th> -->
                    <th>Naziv kategorije</th>
                    <th>Kolicina</th>
                    <th>Update</th>
                    <th>Obrisi</th>
                </tr>
            </thead>
            <?php

       require_once "logic/proizvodiZaAdminTabelu.php";

                        foreach($proizvodi as $p):
                    ?>
            <tbody>
                <tr>
                    <td class="align-middle"><?= $p->naziv?></td>
                    <td class="align-middle"><?= $p->novaCena?></td>
                    <td class="align-middle"><?= $p->staraCena?></td>
                    
                    <td class="align-middle"><?= $p->nazivKat?></td>
                    <td class="align-middle"><?= $p->kolicina?></td>
                    <td class="align-middle"><a href="#FormaUpdate" data-idProizvod="<?= $p->idProizvod?>"
                            data-idkategor="<?= $p->idKat?>" class="btn btn-secondary pokupiIdUpdate">Ažuriraj</a></td>
                    <td class="align-middle"><a href="#" data-id="<?= $p->idProizvod?>"
                            class="btn btn-secondary pokupiIdDelete">Obriši</a></td>
                </tr>
            </tbody>
            <?php endforeach;?>
        </table>
</div>
<!-- forma sa parametrima o proizvodu -->
<div class="col-lg-12 pt-3 text-white pb-5">
        <form id="FormaUpdate" action="logic/update.php" method="post">
            <h2 class="section-subheading text-muted text-center">Izmeni</h2>
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div >
                    <label class="text-dark">Naziv:</label>
                        <input id="nazivProizvoda" name="nazivProizvoda" class="form-control"/>
                    </div>
                    <div >
                    <label class="text-dark">Nova cena:</label>
                        <input id="novaCena" name="novaCena" class="form-control"/>
                    </div>
                    <div >
                    <label class="text-dark">Stara cena:</label>
                        <input id="staraCena" name="staraCena" class="form-control"/>
                    </div>
                    <div >
                    <label class="text-dark">Količila:</label>
                        <input id="kolicina" name="kolicina" class="form-control"/>
                    </div>
                    <div >
                    <label class="text-dark">Kategorija:</label>
                        <select id="kategorijeProiz" name= "kategorijeProiz">

                        </select>
                    </div>
                    <div >
                        <input class="form-control" name="idProizvod" id="idProizvod" type="hidden"/>
                    </div>

                    <div class="clearfix"></div>
                    <div class="col-lg-12 text-center">
                        <div id="success"></div>
                        <input type="submit" id="updatuj" name="updatuj" class="btn btn-primary btn-xl text-uppercase"
                            value="Update" />
                    </div>
                </div>
        </form>
    </div>