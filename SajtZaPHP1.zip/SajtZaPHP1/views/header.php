
      <!-- pocetak slidera -->
      <br><br>
      <div class="bd-example">
        <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
            <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner">
            <div class="carousel-item active">
              <img src="images/pcela1.png" class="d-block w-100" alt="pcele1">
              <div class="carousel-caption d-none d-md-block zatamljeno">
                <h5>KO SMO MI?</h5>
                <p>Mi smo samostalna zanatska radnja koja nudi pčelarsku opremu, proizvode, hranu za pčele i naravno savete. </p> 
              </div>
            </div>
            <div class="carousel-item">
              <img src="images/medonosno.png" class="d-block w-100" alt="ram pun pcela">
              <div class="carousel-caption d-none d-md-block zatamljeno">
                <h5>ZAŠTO BAŠ MI?</h5>
                <p>Jedini smo u gradu, možda čak i u drzavi koji poseduju najsavremeniju opremu i tehnike pčelarenja.</p>
              </div>
            </div>
            <div class="carousel-item">
              <img src="images/pcela2.png" class="d-block w-100" alt="pcela na cvetu">
              <div class="carousel-caption d-none d-md-block zatamljeno">
                <h5 >KAKO VAM MOžEMO POMOĆI?</h5>
                <p >Mozete nas kontaktirati u slučaju da vam treba praktična pomoć, naše udruženje vam može poslati slobodnog pčelara, koji rešava problem.</p>
              </div>
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
      </div>
      <!-- kraj slidera -->
      <h1 class="nevidnjliv">str Pčelarsko carstvo,pcelarska radnja , pčelarska oprema, pčelarski proizvodi,str Pčelarsko carstvo,pcelarska radnja , pčelarska oprema, pčelarski proizvodi,str Pčelarsko carstvo,pcelarska radnja , pčelarska oprema, pčelarski proizvodi </h1>