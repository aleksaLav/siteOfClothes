<div id="login" class="container-fluid pt-2 pb-5" >
    <?php
    
        function phpAlert($msg) {
            echo '<script type="text/javascript">alert("' . $msg . '")</script>';
        }
    
        if(isset($_SESSION['greska'])){
            $error = $_SESSION['greska'];
            phpAlert($error);
            unset($_SESSION['greska']);
        }
    ?>
        <form action="logic/ulogujse.php" method="post"> 
            <h2 class="container-fluid d-flex justify-content-center">ULOGUJ SE</h2>
            <div class="container-fluid d-flex justify-content-center align-items-center flex-wrap">
                <div id="podaciZaRegKorisnika" class="col-xl-7 col-lg-7 col-md-10 col-ms-10 border border-secondary rounded p-3">

                    <div class="styled-input agile-styled-input-top">
                        <input type="text" id='korisImeLogovanje' name="userName" placeholder="Korisničko ime">
                     </div>
                    <div class="styled-input">
                        <input type="password" id='lozinkaLogovanje' name="lozinka" placeholder="Lozinka">
                    </div>
                     <div > 
                        <div class="click">
                            <input id='btnLogovanje' name="btnLogovanje" class="btn border border-dark" type="submit" value="uloguj se" > </div>
                    </div>
                </div>
            </div>
        </form>
    </div>