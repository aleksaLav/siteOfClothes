<div class="container-fluid d-flex justify-content-center">
<table class="table table-stripped table-bordered table-hover">
            <thead>
                <tr>
                    <th>ime</th>               
                    <th>prezime</th>
                    <th>korisničko ime</th>   
                    <th>email</th>            
                </tr>
            </thead>
            <?php

       require_once "logic/korisnikAdmin.php";

                        foreach($korisnik as $p):
                    ?>
            <tbody>
                <tr>
                    <td class="align-middle"><?= $p->ime?></td>
                    <td class="align-middle"><?= $p->prezime?></td>
                    <td class="align-middle"><?= $p->korisnickoIme ?></td>
                    <td class="align-middle"><?= $p->email?></td>
                </tr>
            </tbody>
            <?php endforeach;?>
        </table>
</div>
