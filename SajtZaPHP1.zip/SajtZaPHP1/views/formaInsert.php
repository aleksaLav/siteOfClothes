<div class="col-lg-12 pt-3 text-white" id="FormaInsert">
        <form>
            <h2 class="section-subheading text-muted text-center">Dodaj proizvod u bazu</h2>
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div >
                    <label class="text-dark">Naziv proizvoda:</label>
                        <input id="nazivProizInsert" name="nazivProizInsert" class="form-control"/>
                    </div>
                    <div >
                         <label class="text-dark">Nova cena:</label>
                        <input id="novaCenaInsert" name="novaCenaInsert" class="form-control"/>
                    </div>
                    <div >
                    <label class="text-dark">Stara cena:</label>
                        <input id="staraCenaInsert" name="staraCenaInsert" class="form-control"/>
                    </div>
                    <div >
                    <label class="text-dark">Količila:</label>
                        <input id="kolicinaInsert" name="kolicinaInsert" class="form-control"/>
                    </div>
                    <div >
                        <label class="text-dark">Kategorija:</label>
                        <select id="katProizInsert" name= "katProizInsert">

                        </select>
                    </div>
                    <div >
                    <label class="text-dark">src:</label>
                        <input id="srcInsert" name="srcInsert" class="form-control"/>
                    </div>
                    <label class="text-dark">alt:</label>
                        <input id="altInsert" name="altInsert" class="form-control"/>
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-lg-12 text-center pb-5 pt-4">
                        <div id="success"></div>
                        <input type="button" id="dodaj" name="dodaj" class="btn btn-primary btn-xl text-uppercase"
                            value="Dodaj proizvod" />
                    </div>
                </div>
        </form>
    </div>