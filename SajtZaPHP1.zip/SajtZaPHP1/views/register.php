  <!-- pocetak registracije -->
    
  <div id="registration" class="container-fluid pt-2 pb-5" >
        <form > 
            <h2 class="container-fluid d-flex justify-content-center">REGISTRACIJA</h2>
            <div class="container-fluid d-flex justify-content-center align-items-center flex-wrap mt-4 mb-4">
            <div id="greskeRegistracija" class="border border-danger p-3 text-danger">
            </div>

            </div>
            <div class="container-fluid d-flex justify-content-center align-items-center flex-wrap">
                <div id="podaciZaRegKorisnika" class="col-xl-7 col-lg-7 col-md-10 col-ms-10 border border-secondary rounded p-3">
                    <div class="styled-input agile-styled-input-top">
                        <span id="errorRegisterName"></span>
                        <input type="text" id='imeRegister' name="Name" placeholder="Vaše ime i prezime">
                        <label>Ime mora početi velikim slovom, a ostala malim, korisnik može imati više imena.</label>
                     </div>
                     <div class="styled-input agile-styled-input-top">
                        <span id="errorRegisterName"></span>
                        <input type="text" id='PrezimeRegister' name="Name" placeholder="Vaše ime i prezime">
                        <label>Prezime mora početi velikim slovom, a ostala malim, korisnik može imati više prezimena.</label>
                     </div>
                    <div class="styled-input">
                        <span id="errorRegisterEmail"></span>
                        <input type="email" id='emailRegister' name="Email" placeholder="Unesite vaš email"> 
                        <label>Primer formata za email: nesto-@gmail.com</label>
                    </div>
                    <div class="styled-input agile-styled-input-top">
                        <span id="errorRegisterUserName"></span>
                        <input type="text" id='korisnickoIme' name="Name" placeholder="Vaše korisničko ime">
                        <label>Korisničko ime može biti bilo šta, npr. Vaš nadimak: mika12</label>
                     </div>
                    <div class="styled-input">
                        <span class="errorRegisterPassword"></span>
                        <input type="password" id='lozinka' name="password" placeholder="Vaša lozinka">
                        <label>Preporuka je da lozinka uključuje brojeve i specijalne znakove- npr. neko1237/12*@</label> 
                    </div>
                    <div class="styled-input">
                        <span class="errorRegisterPassword"></span>
                        <input type="password" id='lozinkaPotvrda' name="password2" placeholder="Potvrda Vaše lozinke"> 
                    </div>
                     <div > 
                        <div class="click">
                            <input id='btnRegistruj' class="btn border border-dark" type="button" value="registruj se" > </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- kraj registracije -->