<?php

ob_start();
session_start();

if(isset($_POST['btnLogovanje'])){
    $korisnickoIme=$_POST['userName'];
    $lozinka = $_POST['lozinka'];

    // validacija
    $greske = [];

    $REGkorisnickoIme="/^[A-zžđščć\s\/\-\_\+\@\,\.\'\"\%\d]{3,15}$/";
    $REGlozinka="/^.{4,15}$/";

    if(!preg_match($REGkorisnickoIme, $korisnickoIme)){
        $greske[] = "korisnikime nije ok";
    }
    if(!preg_match($REGlozinka, $lozinka)){
        $greske[] = "Lozinka nije ok";
    }

    if(count($greske) == 0){
        require "konekcija.php";

        $priprema = $konekcija->prepare("SELECT k.*,u.naziv AS naziv FROM korisnik k INNER JOIN uloga u ON k.idUloga = u.idUloga WHERE korisnickoIme = :korisnickoIme AND lozinka = :lozinka");
    
        $priprema->bindParam(":korisnickoIme", $korisnickoIme);

        $lozinka = md5($lozinka);
        
        $priprema->bindParam(":lozinka", $lozinka);

        
        try {
            $uspelo = $priprema->execute();
            if($uspelo && $priprema->rowCount() == 1){
                $korisnik = $priprema->fetch();
                $_SESSION['korisnik'] = $korisnik;

                if($korisnik->naziv == "korisnik"){
                    header("Location: ../index.php");
                   
                } else if($korisnik->naziv == "admin"){
                    header("Location: ../admin.php");
                }
            }
            else{
                $greska  = "Proverite vase kredencijale!";
                $_SESSION['greska'] = $greska;
                header("Location: ../index.php?page=ulogujse");

            }
        } catch (PDOException $e) {
                echo $e->getMessage();
        }
    } else {
        $_SESSION['greske'] = $greske;
        header("Location: ../index.php");
    }

}

