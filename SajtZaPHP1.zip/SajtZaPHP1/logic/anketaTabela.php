<?php 
require_once "konekcija.php";

$upit = "SELECT p.naziv as naziv,count(o.idProizvod) as broj
FROM proizvod p inner join izabranodgovora o on o.idProizvod=p.idProizvod
group by p.idProizvod;
";
$proizvodi = $konekcija->query($upit)->fetchAll();
?>