<?php
    ob_start();
    require "konekcija.php";
    header("Content-type:application/json");
    $data = null;
    $code = 404;

    if(isset($_POST['send'])){
        $naziv = $_POST['naziv'];
        $novaCena = $_POST['novaCena'];
        $staraCena = $_POST['staraCena'];
        $kategorija = $_POST['katProiz'];
        
        $kolicina = $_POST['kolicina'];  
        $src = $_POST['src'];
        $alt = $_POST['alt'];



        $upitProizvodi = "INSERT INTO proizvod VALUES(NULL,:naziv,:idKat,:kolicina)";

        $pripremaProizvoda = $konekcija->prepare($upitProizvodi);

        $pripremaProizvoda->bindParam(':naziv',$naziv);
        $pripremaProizvoda->bindParam(':idKat',$kategorija);
        $pripremaProizvoda->bindParam(':kolicina',$kolicina);
        

        $upitCena = "INSERT INTO cena VALUES(:idProizvod,:stara,:nova)";

        $pripremaCena = $konekcija->prepare($upitCena);

        $pripremaCena->bindParam(':idProizvod',$poslednjiDodat);
        $pripremaCena->bindParam(':stara',$staraCena);
        $pripremaCena->bindParam(':nova',$novaCena);

        $upitSlika= "INSERT INTO slika VALUES(:idProizvod,:src,:alt)";

        $pripramaSlika = $konekcija->prepare($upitSlika);

        $pripramaSlika->bindParam(':idProizvod',$poslednjiDodat);
        $pripramaSlika->bindParam(':src',$src);
        $pripramaSlika->bindParam(':alt',$alt);

        
        try {
            $konekcija->beginTransaction();
            $pripremaProizvoda->execute();
            $poslednjiDodat = $konekcija->lastInsertId();
            $pripremaCena->execute();
            $pripramaSlika->execute();
            $konekcija->commit();
            
            $code=202;
           
        } catch (PDOException $e) {
            $konekcija->rollback();
           $code = 409;
            echo $e->getMessage();
        }

    }
    http_response_code($code);
    echo json_encode($data);
?>