<?php 
  if(isset($_POST['send'])){
      $idProizvod=$_POST['idproiz'];
      require "konekcija.php";
  $proizvodi= $konekcija->query("SELECT p.*,s.*,c.*,k.naziv as nazivKat from proizvod p inner join kategorija k on p.idKat=k.idKategorija  inner join slika s  on p.idProizvod=s.idProizvod inner join cena c on p.idProizvod=c.idProizvod where p.idProizvod=$idProizvod")->fetch();

  echo json_encode($proizvodi); 
    
  }
 
  ?>