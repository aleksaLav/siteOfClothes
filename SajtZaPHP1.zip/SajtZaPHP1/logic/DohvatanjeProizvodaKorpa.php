<?php 
    header("Content-type:application/json");
  require "konekcija.php";
  // $trenutnaStranica=isset($_GET['stranica'])?$_GET['stranica']:1;

  $proizvodiFiltriranje= $konekcija->query("SELECT p.*,s.*,c.*,k.naziv as nazivKat from proizvod p inner join kategorija k on p.idKat=k.idKategorija  inner join slika s  on p.idProizvod=s.idProizvod inner join cena c on p.idProizvod=c.idProizvod")->fetchAll();


    echo json_encode($proizvodiFiltriranje);
  ?>