<?php
    ob_start();
    session_start();
    require_once "konekcija.php";
    header("Content-type:application/json");
    $code = 404;
    $data = null;

    if(isset($_POST['send'])){
        $proizvod = $_POST['id'];
        $idKorisnik = $_SESSION['korisnik']->idKorisnik;
        $upitAnketaAktivna = "SELECT * FROM anketa WHERE aktivna = 1";
        $priprema = $konekcija->query($upitAnketaAktivna)->fetch();
        $idAnketa = $priprema->idAnketa;


        $upitAnketaAktivna = "SELECT * FROM anketa a INNER JOIN odgovor o ON a.idAnketa=o.idAnketa WHERE idKorisnik = :idKorisnik AND aktivna = 1";
        $priprema1 = $konekcija->prepare($upitAnketaAktivna);
        $priprema1->bindParam(':idKorisnik',$idKorisnik);
        $priprema1->execute();

        if($priprema1->rowCount() == 0){
            $upisOdgovoraKorisnika = "INSERT INTO izabranodgovora VALUES(:idKorisnik,:proizvod)";
            $priprema2 = $konekcija->prepare($upisOdgovoraKorisnika);
            $priprema2->bindParam(':idKorisnik',$idKorisnik);
            $priprema2->bindParam(':proizvod',$proizvod);
            try {
                $konekcija->beginTransaction();
                $priprema2->execute();
                $konekcija->commit();
                $code = 202;
            } catch (PDOException $e) {
                $konekcija->rollback();
                $code = 500;
                echo $e->getMessage();
            }

            $korisnikIPitanje = "INSERT INTO odgovor VALUES(:idKorisnik,:idAnketa)";
            $priprema3 = $konekcija->prepare($korisnikIPitanje);
            $priprema3->bindParam(':idKorisnik',$idKorisnik);
            $priprema3->bindParam(':idAnketa',$idAnketa);
            try {
                $konekcija->beginTransaction();
                $priprema3->execute();
                $konekcija->commit();
                $code = 202;
            } catch (PDOException $e) {
                $konekcija->rollback();
                $code = 500;
                echo $e->getMessage();
            }
        }else{
            $code = 500;
        }
    }
    http_response_code($code);
    echo json_encode($data);
?>