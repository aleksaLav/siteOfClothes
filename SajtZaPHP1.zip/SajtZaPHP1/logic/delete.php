<?php
    require_once "konekcija.php";
    if(isset($_POST['id'])){

        $id = $_POST['id'];
        

        $upit = "DELETE FROM proizvod WHERE idProizvod = :id";

        $priprema = $konekcija->prepare($upit);

        $priprema->bindParam(':id',$id);


        try {

            $priprema->execute();
            if($priprema->execute()){
                $code = 202;
            }else{
                $code = 500;
            }

        } catch (PDOException $e) {

            $code = 500;
            echo $e->getMessage();
        }
        

    }
    http_response_code($code);
?>