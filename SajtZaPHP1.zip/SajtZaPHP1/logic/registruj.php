<?php

ob_start();
header("Content-type:application/json");
session_start();
$code = 404;
$data = null;

if(isset($_POST['send'])){
    $ime = $_POST['Ime'];
    $prezime = $_POST['Prezime'];
    $korisnickoIme=$_POST['UserName'];
    $email = $_POST['Email'];
    $lozinka = $_POST['Password'];
    $lozinkaPonovo = $_POST['OpetPassword'];

    $REGimePrezime="/^[A-ZŽĐŠČĆ][a-zžđščć]{2,20}(\s[A-ZŽĐŠČĆ][a-zžđščć]{2,20})?$/";
    $REGemail ="/^[A-zžđščć][A-zžđščć\d\_\.\-]+\@[a-z]{3,10}(\.[a-z]{2,4})+$/";
    $REGkorisnickoIme="/^[A-zžđščć\s\/\-\_\+\@\,\.\'\"\%\d]{3,15}$/";
    $REGlozinka="/^.{4,15}$/";

    $greske = [];
    
    if(!preg_match($REGimePrezime, $ime)){
        $greske[] = "Proverite ime, mora početi velikim slovom,a ostala malim, mora biti napisano latiničnim pismom!";
    }

    if(!preg_match($REGimePrezime, $prezime)){
        $greske[] = "Proverite prezime, mora početi velikim slovom,a ostala malim, mora biti napisano latiničnim pismom!";
    }

    if(!preg_match($REGkorisnickoIme, $korisnickoIme)){
        $greske[] = "Proverite korisnočko ime, možda već postoji isto kor. ime, mora sadžati min 3, a max 15 karaktera!";
    }

    if(!preg_match($REGemail, $email)){
        $greske[] = "Proverite format email-a, možda već postoji isti email!";
    }

    if(!preg_match($REGlozinka, $lozinka)){
        $greske[] = "Lozinka mora sadržati min 4, a max 15 karaktera! ";
    }

    if($lozinka != $lozinkaPonovo){
        $greske[] = "Lozinke se ne poklapaju!";
    }

    if(count($greske) == 0) {
        require "konekcija.php";
        $upit = "INSERT INTO korisnik VALUES (NULL, :ime, :prezime,:korisnickoIme, :email, :lozinka, 2)";// hardcode idUloga , uvek 2 jer svi su korisnici , asamo jedan admin !!!
        
        $priprema = $konekcija->prepare($upit);
        $priprema->bindParam(":ime", $ime);
        $priprema->bindParam(":prezime", $prezime);
        $priprema->bindParam(":email", $email);
        $priprema->bindParam(":korisnickoIme", $korisnickoIme);

        $lozinka = md5($lozinka);
        $priprema->bindParam(":lozinka", $lozinka);


        try {
            $uspelaREG = $priprema->execute();

            if($uspelaREG){
                $code = 202;
            }else{
                $code = 500;
            }
 
        } catch(PDOException $ex) {

            $code =409;
            echo $ex->getMessage();

        }
        

    } else {
        $data = $greske;
        $code = 422;
    }
    http_response_code($code);
    echo json_encode($data);
}

