<?php
    session_start();
    require_once "konekcija.php";
    header("Content-type:application/json");
    $code = 404;
    $data = null;
    if(isset($_POST['send'])){
        $proizvodi = $_POST['proizvodiLS'];

        if(isset($_SESSION['korisnik']) && $_SESSION['korisnik']->naziv == 'korisnik'){
            $idKorisnik = $_SESSION['korisnik']->idKorisnik;
        }
        $upisUTabeluPorudz="INSERT into porudzbina (`idKorisnik`) values($idKorisnik)";

        try {
            $konekcija->beginTransaction();
            $konekcija->query($upisUTabeluPorudz);
            $idPorudzbina = $konekcija->lastInsertId();
            $konekcija->commit();
            $code = 202;
        } catch (PDOException $e) {
            $konekcija->rollback();
            $code = 500;
            echo $e->getMessage();
        }
        $upisUTabeluProduzDetalji = "INSERT INTO detaljiporudzbine VALUES";

        $dodakDelovaZaUpit=[];
        

        if(is_array($proizvodi) || is_object($proizvodi)){
            foreach($proizvodi as $p){
                $dodakDelovaZaUpit[] = '(  NULL  ,' . $p['id'] . ',' . $p['quantity'] . ',' . $p['quantity']*$p['price']  . ',' .$idPorudzbina . ')';
            }
        }
        
        $upisUTabeluProduzDetalji .= implode(',',$dodakDelovaZaUpit);
        
        try {

            $konekcija->query($upisUTabeluProduzDetalji);


            $code = 202;
        } catch (PDOException $e) {

            $code = 500;
            echo $e->getMessage();
        }
    }
    http_response_code($code);
    echo json_encode($data);
?>