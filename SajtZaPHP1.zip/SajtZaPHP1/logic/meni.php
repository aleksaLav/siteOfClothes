<?php
    require_once "konekcija.php";

    $upit = "SELECT * FROM meni";

    $izvrsi = $konekcija->query($upit)->fetchAll();
    
?>