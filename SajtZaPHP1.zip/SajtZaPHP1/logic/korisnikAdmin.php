<?php 
require_once "konekcija.php";

$upit = "SELECT * from korisnik";
$korisnik = $konekcija->query($upit)->fetchAll();
?>