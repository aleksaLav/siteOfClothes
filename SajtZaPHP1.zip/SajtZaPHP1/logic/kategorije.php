<?php
    require "konekcija.php";

    $upit = "SELECT * FROM kategorija";

    $rez = $konekcija->query($upit);

    $data = $rez->fetchAll();

    echo json_encode($data);

?>