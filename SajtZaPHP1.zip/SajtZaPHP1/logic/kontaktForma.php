<?php
 ob_start();

 header("Content-type:application/json");
 $data = null;
$code=404;
if(isset($_POST['send'])){
    $imeIPrez=$_POST['imePrez'];
    $email = $_POST['email'];
    $telefon = $_POST['telefon'];
    $poruka= $_POST['poruka'];

        require "konekcija.php";
      
        $priprema = $konekcija->prepare("INSERT INTO  kontaktforma VALUES(null,:imePrezime,:email ,:telefon ,:poruka)");
    
        $priprema->bindParam(":imePrezime",$imeIPrez);
        $priprema->bindParam(":email",$email);
        $priprema->bindParam(":telefon",$telefon);
        $priprema->bindParam(":poruka",$poruka);

         
        try {
            $konekcija->beginTransaction();
            $priprema->execute();
            $konekcija->commit();
            
            $code=202;
           
        } catch (PDOException $e) {
            $konekcija->rollback();
           $code = 409;
            echo $e->getMessage();
        }
       
        header("Location: ../index.php?page=pocetna");


}
http_response_code($code);
echo json_encode($data);

