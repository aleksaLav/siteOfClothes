<?php 
    header("Content-type:application/json");
  require "konekcija.php";
  // $trenutnaStranica=isset($_GET['stranica'])?$_GET['stranica']:1;
  $actual_link = $_SERVER['HTTP_REFERER'];
  $trenutnaStranica=explode("&",$actual_link)[1];
  $trenutnaStranicaOpet=explode("=",$trenutnaStranica)[1];
  // echo $actual_link . "<br/>";
  $limit=5;
  $kreni=($trenutnaStranicaOpet-1)*$limit;
  $brojProiz= $konekcija->query("SELECT count(*) as broj from proizvod")->fetch()->broj;

  $proizvodi= $konekcija->query("SELECT p.*,s.*,c.*,k.naziv as nazivKat from proizvod p inner join kategorija k on p.idKat=k.idKategorija  inner join slika s  on p.idProizvod=s.idProizvod inner join cena c on p.idProizvod=c.idProizvod limit $kreni,$limit")->fetchAll();

  $proizvodiFiltriranje= $konekcija->query("SELECT p.*,s.*,c.*,k.naziv as nazivKat from proizvod p inner join kategorija k on p.idKat=k.idKategorija  inner join slika s  on p.idProizvod=s.idProizvod inner join cena c on p.idProizvod=c.idProizvod")->fetchAll();

  $data = [
    "brojProizvoda"=>$brojProiz,
    "proizvodiFiltriranje"=>$proizvodiFiltriranje,
    "proizvodi"=> $proizvodi
  ];
    echo json_encode($data);
  ?>