<?php 
require_once "konekcija.php";

$upit = "SELECT p.naziv as naziv, d.cena as cena, d.kolicina as kolicina,k.ime as ime, k.prezime as prezime,por.datumNarucivanja as datum from proizvod p inner join detaljiporudzbine d on p.idProizvod=d.idProizvoda inner join porudzbina por on por.idPorudzbina=d.idPorudzbine inner join korisnik k on k.idKorisnik=por.idKorisnik";
$porudzbina = $konekcija->query($upit)->fetchAll();
?>