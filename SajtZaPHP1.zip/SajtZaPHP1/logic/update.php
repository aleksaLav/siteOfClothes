<?php

    if(isset($_POST['updatuj'])){
        $id = $_POST['idProizvod'];
        $naziv = $_POST['nazivProizvoda'];
        $novaCena = $_POST['novaCena'];
        $staraCena = $_POST['staraCena'];
        $kategorija = $_POST['kategorijeProiz'];
        $kolicina = $_POST['kolicina'];
        // $regNaziv ="/^.{3,100}$/";
        // $regCena = "/^\d{10}(.\d{2})?$/"; 
        // $regKolicina="/^[1-9]\d{5}$/";
        // $greska = false;
        // if(!preg_match($regNaziv, $naziv)) {
        //     echo "Naziv nije ok!!";
        //     $greska = true;
        // }
        // if(!preg_match($regCena, $novaCena)){
        //     echo "Cena nije ok!";
        //     $greska = true;
        // }
        // if(!preg_match($regCena, $staraCena)){
        //     echo "Cena nije ok!";
        //     $greska = true;
        // }
        // if(!preg_match($regKolicina, $kolicina)){
        //     echo "kolicina!";
        //     $greska = true;
        // }

        // if(!$greska){
            require "konekcija.php";
            // $pripremaProizvod = $konekcija->prepare("UPDATE proizvod SET naziv=:naziv, kolicina=:kolicina, idKat = :kategorija WHERE idProizvod = :id");
            // $pripremaProizvod->bindParam(":naziv", $naziv);
            // $pripremaProizvod->bindParam(":kategorija", $kategorija);
            // $pripremaProizvod->bindParam(":id", $id);
            // $pripremaProizvod->bindParam(":kolicina", $kolicina);
            // $pripremaProizvod->execute();

            // $pripremaCena=$konekcija->prepare("UPDATE cena SET staraCena=:staraCena, novaCena=:novaCena WHERE idProizvod = :id");
            // $pripremaCena->bindParam(":novaCena", $novaCena);
            // $pripremaCena->bindParam(":id", $id);
            // $pripremaCena->bindParam(":staraCena", $staraCena);
            // $pripremaCena->execute();
            try {
                $pripremaProizvod = $konekcija->prepare("UPDATE proizvod SET naziv=:naziv, kolicina=:kolicina, idKat = :kategorija WHERE idProizvod = :id");
            $pripremaProizvod->bindParam(":naziv", $naziv);
            $pripremaProizvod->bindParam(":kategorija", $kategorija);
            $pripremaProizvod->bindParam(":id", $id);
            $pripremaProizvod->bindParam(":kolicina", $kolicina);
           

            $pripremaCena=$konekcija->prepare("UPDATE cena SET staraCena=:staraCena, novaCena=:novaCena WHERE idProizvod = :id");
            $pripremaCena->bindParam(":novaCena", $novaCena);
            $pripremaCena->bindParam(":id", $id);
            $pripremaCena->bindParam(":staraCena", $staraCena);

            $konekcija->beginTransaction();
            $pripremaProizvod->execute();
            $pripremaCena->execute();
            $konekcija->commit();
           
            } catch (PDOException $e) {
                $konekcija->rollback();
            }
            if($pripremaProizvod && $pripremaCena){
                echo "AZURIRAN PROIZVOD!!";
                header("Location: ../admin.php");
            }
            

        // }
    }


?>