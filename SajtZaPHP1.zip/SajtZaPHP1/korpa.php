<?php session_start();?>
<?php require "views/head.php";?>
<?php require "views/nav.php";?>
<?php require "views/header.php";?>
 <?php require "views/cart.php";?>
<?php require "views/contact.php";?> 
<?php require "views/footer.php";?>
<?php require "views/script.php";?>